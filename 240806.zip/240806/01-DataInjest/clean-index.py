import os
from azure.core.credentials import AzureKeyCredential
from azure.search.documents.indexes import SearchIndexerClient, SearchIndexClient
from dotenv import load_dotenv
load_dotenv()

# 消去しないインデックスはここに追記
lst_index_not_remove = ["gptkbindex", "db-cashe", "db-faq"]

search_service_name = os.environ["AZURE_SEARCH_SERVICE"]
admin_key = os.environ["AZURE_SEARCH_SERVICE_ADMIN_KEY"]

credential = AzureKeyCredential(admin_key)
search_index_client = SearchIndexClient(endpoint=os.environ["AZURE_SEARCH_SERVICE_ENDPOINT"], credential=credential)

indexes_itempaged = search_index_client.list_index_names()
indexes_lst = [index for index in indexes_itempaged]

for index in indexes_lst:
    if index not in lst_index_not_remove:
        search_index_client.delete_index(index)