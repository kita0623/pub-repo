import glob
import os
import sys
import subprocess
from pypdf import PdfReader, PdfWriter
from pdf2image import convert_from_path
import platform
import shutil

from dotenv import load_dotenv
load_dotenv()

current_os = platform.system()
print(f"current_os: {current_os}")


##############################################################
# Config
##############################################################
# input
path_data = os.path.join(os.path.dirname(__file__), 'data')

# output
path_data_process_01_pdf = os.path.join(os.path.dirname(__file__), 'data-process', '01-pdf')
path_data_process_02_pdf_pages = os.path.join(os.path.dirname(__file__), 'data-process', '02-pdf-pages')
path_data_process_03_png_pages = os.path.join(os.path.dirname(__file__), 'data-process', '03-png-pages')

##############################################################
# pptxファイルやdocxファイルをPDFに変換 & PDFファイルの分割 & 画像ファイルへの変換
##############################################################

lst_path_index_unit_folder = glob.glob(os.path.join(path_data, '*'))

for path_index_unit_folder in lst_path_index_unit_folder:
    
    # 全てのpptxファイル、docxファイル、docファイル、pdfファイルのpathのリストを取得
    lst_path_pptx = glob.glob(os.path.join(path_index_unit_folder, '*.pptx'))
    lst_path_docx = glob.glob(os.path.join(path_index_unit_folder, '*.docx'))
    lst_path_doc = glob.glob(os.path.join(path_index_unit_folder, '*.doc'))
    lst_path_xlsx = glob.glob(os.path.join(path_index_unit_folder, '*.xlsx'))
    lst_path_pdf = glob.glob(os.path.join(path_index_unit_folder, '*.pdf'))


    def convert_and_split_pdf(file_path, extension):
        
        #
        # data-process へ既に反映済みであればスキップ
        #
        filebody = os.path.basename(file_path).split(f'.{extension}')[0]

        lst_path_in_01pdf = glob.glob(os.path.join(path_data_process_01_pdf, '*.pdf'))
        lst_filebody_in_data_process = [os.path.basename(path_pdf).split('.pdf')[0].split('_type_')[0] for path_pdf in lst_path_in_01pdf]
        if filebody in lst_filebody_in_data_process:
            return
        
        
        #
        # pptxファイルやdocxファイル、docファイルをPDFに変換 (unoconvコマンド + subprocess)
        # PDFファイルはそのままコピー
        #
        print(f"*** Processing {file_path} ... ***")

        ### Windows ###
        if current_os == 'Windows':
            if extension == 'pdf':
                shutil.copy(file_path, path_data_process_01_pdf)
                pdf_name = os.path.basename(file_path).split(f'.{extension}')[0] + '.pdf'
                pdf_path = os.path.join(path_data_process_01_pdf, pdf_name)
            else:
                pdf_name = os.path.basename(file_path).split(f'.{extension}')[0] + f'_type_{extension}.pdf'
                pdf_path = os.path.join(path_data_process_01_pdf, pdf_name)
                if extension == 'pptx' or extension == 'docx' or extension == 'doc':
                    # subprocess.run(['python', '../../InstalledLibraries/unoconv/unoconv', '-f', 'pdf', '-o', pdf_path, file_path])
                    subprocess.run(['python', '../InstalledLibraries/unoconv/unoconv', '-f', 'pdf', '-o', pdf_path, file_path])
                elif extension == 'xlsx':
                    subprocess.call([
                        'C:\Program Files\LibreOffice\program\soffice.exe',
                        '--headless',
                        '--convert-to', 'pdf:calc_pdf_Export',
                        '--outdir', path_data_process_01_pdf,
                        file_path
                    ])
                    old_pdf_name = os.path.basename(file_path).split('.xlsx')[0] + '.pdf'
                    old_pdf_path = os.path.join(path_data_process_01_pdf, old_pdf_name)
                    os.rename(old_pdf_path, pdf_path)
                else:
                    pass
        
        ## Mac OS ###
        elif current_os == 'Darwin':  # Darwin is the name for the Mac OS X kernel
            if extension == 'pdf':
                shutil.copy(file_path, path_data_process_01_pdf)
                pdf_name = os.path.basename(file_path).split(f'.{extension}')[0] + '.pdf'
                pdf_path = os.path.join(path_data_process_01_pdf, pdf_name)
            else:
                pdf_name = os.path.basename(file_path).split(f'.{extension}')[0] + f'_type_{extension}.pdf'
                pdf_path = os.path.join(path_data_process_01_pdf, pdf_name)
                if extension == 'pptx' or extension == 'docx' or extension == 'doc':
                    subprocess.run(['unoconv', '-f', 'pdf', '-o', pdf_path, file_path])
                elif extension == 'xlsx':
                    subprocess.call([
                        '/Applications/LibreOffice.app/Contents/MacOS/soffice',
                        '--headless',
                        '--convert-to', 'pdf:calc_pdf_Export',
                        '--outdir', path_data_process_01_pdf,
                        file_path
                    ])
                    old_pdf_name = os.path.basename(file_path).split('.xlsx')[0] + '.pdf'
                    old_pdf_path = os.path.join(path_data_process_01_pdf, old_pdf_name)
                    os.rename(old_pdf_path, pdf_path)
                else:
                    pass
            
        else:
            print("OS is not Supported. Please check your OS")
            sys.exit(1)
        
        #
        # PDFファイルのページ分割 & 画像化
        #
        pdf_basename = pdf_name.split('.pdf')[0]
        input_pdf = PdfReader(pdf_path)
        for i in range(len(input_pdf.pages)):
            # PDFファイルをページ単位で分割 (pypdf)
            output_pdf = PdfWriter()
            output_pdf.add_page(input_pdf.pages[i])
            with open(os.path.join(path_data_process_02_pdf_pages, f"{pdf_basename}_page_{i+1}.pdf"), "wb") as outputStream:
                output_pdf.write(outputStream)
            # 画像ファイル(png)に変換 (pdf2image)
            images = convert_from_path(os.path.join(path_data_process_02_pdf_pages, f"{pdf_basename}_page_{i+1}.pdf"))
            image = images[0]
            image.save(os.path.join(path_data_process_03_png_pages, f"{pdf_basename}_page_{i+1}.png"), 'PNG')


    # pptxファイル
    for path_pptx in lst_path_pptx:
        convert_and_split_pdf(path_pptx, 'pptx')

    # docxファイル
    for path_docx in lst_path_docx:
        convert_and_split_pdf(path_docx, 'docx')

    # docファイル
    for path_doc in lst_path_doc:
        convert_and_split_pdf(path_doc, 'doc')

    # xlsxファイル
    for path_xlsx in lst_path_xlsx:
        convert_and_split_pdf(path_xlsx, 'xlsx')

    # pdfファイル
    for path_pdf in lst_path_pdf:
        convert_and_split_pdf(path_pdf, 'pdf')

