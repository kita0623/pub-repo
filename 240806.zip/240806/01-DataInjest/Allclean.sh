#!/bin/bash

source .env

rm -f ./data-process/01-pdf/*
rm -f ./data-process/02-pdf-pages/*
rm -f ./data-process/03-png-pages/*

./.venv/bin/python clean-index.py
./.venv/bin/python clean-container.py