#!/bin/bash

source .env

./.venv/bin/python 01-convertPDF_splitPages_convertPNG.py
./.venv/bin/python 02-dataIngestion.py