import base64
import glob
import html
import io
import json
import jsonpickle
import os
import re
import sys
import time
import pandas as pd
import requests
import openai
from natsort import natsorted

from azure.ai.formrecognizer import DocumentAnalysisClient
from azure.core.credentials import AzureKeyCredential
from azure.identity import DefaultAzureCredential
from azure.search.documents import SearchClient
from azure.search.documents.indexes import SearchIndexClient
from azure.search.documents.indexes.models import (
    ExhaustiveKnnAlgorithmConfiguration,
    ExhaustiveKnnParameters,
    HnswAlgorithmConfiguration,
    HnswParameters,
    SearchField,
    SearchFieldDataType,
    SearchIndex,
    SearchableField,
    SemanticConfiguration,
    SemanticField,
    SemanticPrioritizedFields,
    SemanticSearch,
    SimpleField,
    VectorSearch,
    VectorSearchAlgorithmConfiguration,
    VectorSearchAlgorithmKind,
    VectorSearchAlgorithmMetric,
    VectorSearchProfile,
)
from azure.storage.blob import BlobServiceClient
from openai import AzureOpenAI
from pypdf import PdfReader, PdfWriter
from tenacity import retry, stop_after_attempt, wait_random_exponential

from dotenv import load_dotenv
load_dotenv()


#####################################################################################################################
# Config
#####################################################################################################################

# Azure Blob Storage
AZURE_STORAGE_CONTAINER: str = os.environ["CONTAINER_NAME"]
AZURE_STORAGE_CONNECTION_STRING: str = os.getenv("AZURE_STORAGE_CONNECTION_STRING")

# Azure AI Search
AZURE_SEARCH_SERVICE_ENDPOINT: str = os.getenv("AZURE_SEARCH_SERVICE_ENDPOINT")
AZURE_SEARCH_SERVICE_ADMIN_KEY: str = os.getenv("AZURE_SEARCH_SERVICE_ADMIN_KEY")
search_analyzer_name: str = "ja.lucene"
credential = AzureKeyCredential(AZURE_SEARCH_SERVICE_ADMIN_KEY)

# Azure AI Document Intelligence
AZURE_DOCUMENT_INTELLIGENCE_KEY: str = os.getenv("AZURE_DOCUMENT_INTELLIGENCE_KEY")
AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT: str = os.getenv("AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT")
document_intelligence_creds: str = AzureKeyCredential(AZURE_DOCUMENT_INTELLIGENCE_KEY)

# Azure OpenAI Service
aoai_client = AzureOpenAI(
    api_key = os.getenv("AZURE_OPENAI_API_KEY"),
    api_version = "2023-05-15",
    azure_endpoint = os.getenv("AZURE_OPENAI_ENDPOINT")
)

# OpenAI
oai_client = openai.OpenAI(api_key=os.environ["OPENAI_API_KEY"])


#####################################################################################################################
# Utility
#####################################################################################################################

def elapsed_time(t):
    elapsed_time = int(time.time() - t)
    elapsed_hour = elapsed_time // 3600
    elapsed_minute = (elapsed_time % 3600) // 60
    elapsed_second = (elapsed_time % 3600 % 60)
    return str(elapsed_hour).zfill(2) + ":" + str(elapsed_minute).zfill(2) + ":" + str(elapsed_second).zfill(2)


def filename_to_id(filename):
    filename_ascii = re.sub("[^0-9a-zA-Z_-]", "_", filename)
    filename_hash = base64.b16encode(filename.encode('utf-8')).decode('ascii')
    return f"file-{filename_ascii}-{filename_hash}"


#####################################################################################################################
# フィールド作成
#####################################################################################################################

#*******************************************************#
# filekeyフィールド
#*******************************************************#
def generate_filekey(filename):
    return filename.split('_type_')[0].split('_page_')[0].split('.')[0]


#*******************************************************#
# embeddingフィールド
#*******************************************************#

def before_retry_sleep(retry_state):
    print("Rate limited on the OpenAI embeddings API, sleeping before retrying...")

@retry(wait=wait_random_exponential(min=15, max=60), stop=stop_after_attempt(15), before_sleep=before_retry_sleep)
def generate_text_embedding_openai(text):
    return aoai_client.embeddings.create(input = [text], model=os.getenv("AZURE_OPENAI_EMB_MODEL_DEPLOYMENT")).data[0].embedding


def generate_text_embedding_aivision(text):
    
    aiVisionEndpoint = os.getenv("AZURE_COMPUTER_VISION_ENDPOINT")
    aiVisionApiKey = os.getenv("AZURE_COMPUTER_VISION_API_KEY")
    
    url = f"{aiVisionEndpoint}/computervision/retrieval:vectorizeText"
    params = {
        "api-version": "2023-02-01-preview",
        "modelVersion": "latest"
    }
    headers = {
        "Content-Type": "application/json",
        "Ocp-Apim-Subscription-Key": aiVisionApiKey
    }
    data = {
        "text": text
    }
    response = requests.post(url, params=params, headers=headers, data=json.dumps(data))
        
    if response.status_code == 200:
        embeddings = response.json()["vector"]
        return embeddings
    else:
        return None
    
    
def generate_image_embedding_aivision(path_img):

    aiVisionEndpoint = os.getenv("AZURE_COMPUTER_VISION_ENDPOINT")
    aiVisionApiKey = os.getenv("AZURE_COMPUTER_VISION_API_KEY")
    
    with open(path_img, "rb") as image_file:
        image_bytes_io = io.BytesIO(image_file.read())
    
    url = f"{aiVisionEndpoint}/computervision/retrieval:vectorizeImage"
    params = {
        "api-version": "2023-02-01-preview",
        "modelVersion": "latest"
    }
    headers = {
        "Content-Type": "application/octet-stream",
        "Ocp-Apim-Subscription-Key": aiVisionApiKey
    }
    response = requests.post(url, params=params, headers=headers, data=image_bytes_io)
    
    if response.status_code == 200:
        embeddings = response.json()["vector"]
        return embeddings
    else:
        return None


#*******************************************************#
# summaryフィールド（要約文）
#*******************************************************#

#####
MAX_TOKENS = 200
#####

def generate_text_summary(text):
    messages = [{"role": "user", "content": f"""
    以下の文書から要約文を作成してください。
    要約文は最大{MAX_TOKENS}トークン程度で作成してください。
    文書:
    {text}
    """}]
    try:
        # response = aoai_client.chat.completions.create(
        #     model=os.getenv("AZURE_OPENAI_GPT4_1106_PREVIEW_DEPLOYMENT"),
        #     messages=messages,
        #     max_tokens=min(MAX_TOKENS*5, 128000),
        #     temperature=0.7
        # )
        response = oai_client.chat.completions.create(
            model="gpt-4o", 
            messages=messages,
            max_tokens=min(MAX_TOKENS*5, 128000),
            temperature=0.7
        )
        response_content = response.choices[0].message.content
        return response_content
    except Exception as e:
        if 'content_filter' in str(e):
            return "Azure OpenAIのコンテンツフィルタリングにより要約文生成に失敗"
        else:
            raise


def generate_image_summary(path_img):
    
    def encode_image(image_path):
        """画像をbase64にエンコードする"""
        with open(image_path, "rb") as image_file:
            return base64.b64encode(image_file.read()).decode("utf-8")
        
    base64_image = encode_image(path_img)
    
    try:
        # response = aoai_client.chat.completions.create(
        #     model=os.getenv("AZURE_OPENAI_GPT4V_DEPLOYMENT"),
        #     messages=[
        #         {
        #             "role": "user",
        #             "content": [
        #                 {"type": "text", "text": f"最大{MAX_TOKENS}トークン程度で、この画像の内容を説明してください。画像中の読み取れる文字はできるだけ説明文に含め、読み取れない文字は勝手に推測しないでください。"},
        #                 {"type": "image_url", "image_url": f"data:image/jpeg;base64,{base64_image}"},
        #             ],
        #         }
        #     ],
        #     max_tokens=min(MAX_TOKENS*5, 128000),
        # )
        response = oai_client.chat.completions.create(
            model="gpt-4o",
            messages=[
                {
                    "role": "user",
                    "content": [
                        {"type": "text", "text": f"最大{MAX_TOKENS}トークン程度で、この画像の内容を説明してください。画像中から読み取れるテキストはできるだけ説明文に含め、読み取れないテキストは勝手に推測しないでください。"},
                        {"type": "image_url", "image_url": {"url": f"data:image/jpeg;base64,{base64_image}"}}
                    ],
                }
            ],
            max_tokens=min(MAX_TOKENS*5, 4096),
        )
        ret_summary = response.choices[0].message.content
        return ret_summary
    except Exception as e:
        return "画像要約文の生成に失敗"


#*******************************************************#
# internaltermsフィールド（独自用語の用語集検索）
#*******************************************************#

def generate_keyphrases_internalterms(text):
    
    #
    # 独自用語を抽出
    #
    messages= [{"role": "user", "content": f"""
    下記本題コンテキストからキーフレーズを抽出してしてください。回答はカンマ区切りで返してください。
    
    ### コンテキスト例 ###
    本日のMTGでは、新規プロジェクト「スマートビジョン」について討議しました。プロジェクトの進行には、PMSの更新が必要です。また、QATからのフィードバックを基に、次回のレビューをRSCを使用して行います。
    
    ### 回答例 ###
    スマートビジョン,PMS,QAT,RSC
    
    ### 本題コンテキスト ###
    {text}
    """}]
    
    # response = aoai_client.chat.completions.create(
    #     model=os.getenv("AZURE_OPENAI_GPT4_1106_PREVIEW_DEPLOYMENT"),
    #     messages= messages,
    # )
    response = oai_client.chat.completions.create(
        model="gpt-4o",
        messages= messages,
        temperature=0, # 再現性を高めるためtemperature=0
    )
    response_content = response.choices[0].message.content
    lst_term = [term.strip() for term in response_content.split(',')]
    
    keyphrases = ",".join(lst_term)
    
    #
    # 用語集から検索
    #
    df_terms = pd.read_csv(os.path.join(os.path.dirname(__file__), 'internal-terms', '用語集.csv'))
    
    df_internalterms = pd.DataFrame(columns=df_terms.columns)
    for term in lst_term:
        ser_term = df_terms.loc[df_terms['略語'].str.lower() == term.lower(),:]
        if not ser_term.empty:
            df_internalterms = pd.concat([df_internalterms, ser_term])
    
    internalterms_str = df_internalterms.to_csv(index=False, header=False, lineterminator='\n')
    
    return keyphrases, internalterms_str


#*******************************************************#
# assumedquestionフィールド（想定質問）
#*******************************************************#

def generate_assumedquestion(text):

    messages = [
    {"role": "system", "content": f"""
    提示文章から根拠を導き出せる質問を作成してください。

    以下の3種類の観点から質問を作成してください。
    ・一般的で抽象的な質問文
    ・専門的で具体的な質問文
    ・包括的な質問文
    質問を作成する際には ### 制約 ### を守ってください。

    ### 制約 ###
    ・質問は全部で3個作ること
    ・質問は日本語で出力すること
    ・「この文章は何ですか」など、どの文章にも適用可能な質問は作成しないこと
    """},
    {"role":"user","content":text}
    ]
    
    functions = [
        {
            "name": "virtual_func",
            "description": "一般的で抽象的な質問文, 専門的で具体的な質問文, 包括的な質問文 の3つを作成する",
            "parameters": {
                "type": "object",
                "properties": {
                    "general": {
                        "type": "string",
                        "description": "一般的で抽象的な質問文"
                    },
                    "professional": {
                        "type": "string",
                        "description": "専門的で具体的な質問文"
                    },
                    "comprehensive": {
                        "type": "string",
                        "description": "包括的な質問文"
                    },
                },
                "required": ["general", "professional", "comprehensive"]
            }
        }
    ]
    
    # response = aoai_client.chat.completions.create(
    #     model=os.getenv("AZURE_OPENAI_GPT4_1106_PREVIEW_DEPLOYMENT"),
    #     messages=messages,
    #     functions=functions,
    #     function_call={"name": "virtual_func"}
    # )
    response = oai_client.chat.completions.create(
        model="gpt-4o",
        messages=messages,
        temperature=0,
        functions=functions,
        function_call={"name": "virtual_func"}
    )
    response_arguments = response.choices[0].message.function_call.arguments
    
    return json.loads(response_arguments)



#####################################################################################################################
# 処理フロー
#####################################################################################################################

def create_index(index_name, unit="chunk"):
    """
    フィールド準備
    """
    #
    # ファイル検索用インデックス
    #
    if unit == "file":
        fields = [
            SimpleField(name="id", type="Edm.String", key=True),
            SimpleField(name="sourcefile", type="Edm.String", filterable=True, facetable=True),
            SimpleField(name="filekey", type="Edm.String", filterable=True, facetable=True),
            SimpleField(name="category", type="Edm.String", filterable=True, facetable=True),
            
            SearchableField(
                name="content", type="Edm.String", analyzer_name=search_analyzer_name
            ),
            SearchableField(
                name="summary", type="Edm.String", analyzer_name=search_analyzer_name
            ),
            
            SearchableField(
                name="keyphrases", type="Edm.String", analyzer_name=search_analyzer_name
            ),
            SearchableField(
                name="internalterms", type="Edm.String", analyzer_name=search_analyzer_name
            ),
            SearchableField(
                name="assumedquestion_general", type="Edm.String", analyzer_name=search_analyzer_name
            ),
            SearchableField(
                name="assumedquestion_professional", type="Edm.String", analyzer_name=search_analyzer_name
            ),
            SearchableField(
                name="assumedquestion_comprehensive", type="Edm.String", analyzer_name=search_analyzer_name
            ),
            
            SearchField(
                name="emb_summary",
                type=SearchFieldDataType.Collection(SearchFieldDataType.Single),
                hidden=False,
                searchable=True,
                filterable=False,
                sortable=False,
                facetable=False,
                vector_search_dimensions=1536, # OpenAI Embedding
                # vector_search_dimensions=1024, # Azure AI Vision Embedding
                vector_search_profile_name="embedding_config",
            ),
            SearchField(
                name="emb_keyphrases",
                type=SearchFieldDataType.Collection(SearchFieldDataType.Single),
                hidden=False,
                searchable=True,
                filterable=False,
                sortable=False,
                facetable=False,
                vector_search_dimensions=1536, # OpenAI Embedding
                # vector_search_dimensions=1024, # Azure AI Vision Embedding
                vector_search_profile_name="embedding_config",
            ),
            SearchField(
                name="emb_assumedquestion_general",
                type=SearchFieldDataType.Collection(SearchFieldDataType.Single),
                hidden=False,
                searchable=True,
                filterable=False,
                sortable=False,
                facetable=False,
                vector_search_dimensions=1536, # OpenAI Embedding
                # vector_search_dimensions=1024, # Azure AI Vision Embedding
                vector_search_profile_name="embedding_config",
            ),
            SearchField(
                name="emb_assumedquestion_professional",
                type=SearchFieldDataType.Collection(SearchFieldDataType.Single),
                hidden=False,
                searchable=True,
                filterable=False,
                sortable=False,
                facetable=False,
                vector_search_dimensions=1536, # OpenAI Embedding
                # vector_search_dimensions=1024, # Azure AI Vision Embedding
                vector_search_profile_name="embedding_config",
            ),
            SearchField(
                name="emb_assumedquestion_comprehensive",
                type=SearchFieldDataType.Collection(SearchFieldDataType.Single),
                hidden=False,
                searchable=True,
                filterable=False,
                sortable=False,
                facetable=False,
                vector_search_dimensions=1536, # OpenAI Embedding
                # vector_search_dimensions=1024, # Azure AI Vision Embedding
                vector_search_profile_name="embedding_config",
            ),
        ]
    
    #
    # チャンク検索用インデックス
    #
    elif unit == "chunk":
        fields = [
            SimpleField(name="id", type="Edm.String", key=True),
            SimpleField(name="sourcefile", type="Edm.String", filterable=True, facetable=True),
            SimpleField(name="sourcepage", type="Edm.String", filterable=True, facetable=True),
            SimpleField(name="filekey", type="Edm.String", filterable=True, facetable=True),
            # SimpleField(name="metadata", type="Edm.String", filterable=True, facetable=True),
            SimpleField(name="category", type="Edm.String", filterable=True, facetable=True),
            
            SearchableField(
                name="content", type="Edm.String", analyzer_name=search_analyzer_name
            ),
            SearchableField(
                name="summary", type="Edm.String", analyzer_name=search_analyzer_name
            ),
            
            SearchableField(
                name="keyphrases", type="Edm.String", analyzer_name=search_analyzer_name
            ),
            SearchableField(
                name="internalterms", type="Edm.String", analyzer_name=search_analyzer_name
            ),
            SearchableField(
                name="assumedquestion_general", type="Edm.String", analyzer_name=search_analyzer_name
            ),
            SearchableField(
                name="assumedquestion_professional", type="Edm.String", analyzer_name=search_analyzer_name
            ),
            SearchableField(
                name="assumedquestion_comprehensive", type="Edm.String", analyzer_name=search_analyzer_name
            ),
            
            SearchField(
                name="embedding",
                type=SearchFieldDataType.Collection(SearchFieldDataType.Single),
                hidden=False,
                searchable=True,
                filterable=False,
                sortable=False,
                facetable=False,
                # vector_search_dimensions=1536, # OpenAI Embedding
                vector_search_dimensions=1024, # Azure AI Vision Embedding
                vector_search_profile_name="embedding_config",
            ),
            SearchField(
                name="emb_summary",
                type=SearchFieldDataType.Collection(SearchFieldDataType.Single),
                hidden=False,
                searchable=True,
                filterable=False,
                sortable=False,
                facetable=False,
                vector_search_dimensions=1536, # OpenAI Embedding
                # vector_search_dimensions=1024, # Azure AI Vision Embedding
                vector_search_profile_name="embedding_config",
            ),
            SearchField(
                name="emb_keyphrases",
                type=SearchFieldDataType.Collection(SearchFieldDataType.Single),
                hidden=False,
                searchable=True,
                filterable=False,
                sortable=False,
                facetable=False,
                vector_search_dimensions=1536, # OpenAI Embedding
                # vector_search_dimensions=1024, # Azure AI Vision Embedding
                vector_search_profile_name="embedding_config",
            ),
            SearchField(
                name="emb_assumedquestion_general",
                type=SearchFieldDataType.Collection(SearchFieldDataType.Single),
                hidden=False,
                searchable=True,
                filterable=False,
                sortable=False,
                facetable=False,
                vector_search_dimensions=1536, # OpenAI Embedding
                # vector_search_dimensions=1024, # Azure AI Vision Embedding
                vector_search_profile_name="embedding_config",
            ),
            SearchField(
                name="emb_assumedquestion_professional",
                type=SearchFieldDataType.Collection(SearchFieldDataType.Single),
                hidden=False,
                searchable=True,
                filterable=False,
                sortable=False,
                facetable=False,
                vector_search_dimensions=1536, # OpenAI Embedding
                # vector_search_dimensions=1024, # Azure AI Vision Embedding
                vector_search_profile_name="embedding_config",
            ),
            SearchField(
                name="emb_assumedquestion_comprehensive",
                type=SearchFieldDataType.Collection(SearchFieldDataType.Single),
                hidden=False,
                searchable=True,
                filterable=False,
                sortable=False,
                facetable=False,
                vector_search_dimensions=1536, # OpenAI Embedding
                # vector_search_dimensions=1024, # Azure AI Vision Embedding
                vector_search_profile_name="embedding_config",
            ),
        ]
    
    else:
        raise ValueError(f"Invalid index unit: {unit}")
    
    # セマンティックランカーの設定
    semantic_config = SemanticConfiguration(
        name="default",
        prioritized_fields=SemanticPrioritizedFields(
            title_field=None,
            keywords_fields=None,
            content_fields=[SemanticField(field_name="content")]
        )
    )
    semantic_search = SemanticSearch(configurations=[semantic_config])

    # ベクトル検索の設定
    vector_search = VectorSearch(
        algorithms=[
            HnswAlgorithmConfiguration(
                name="hnsw_config",
                kind=VectorSearchAlgorithmKind.HNSW,
                parameters=HnswParameters(
                    m=4,
                    ef_construction=400,
                    ef_search=500,
                    metric=VectorSearchAlgorithmMetric.COSINE,
                ),
            ),
        ],
        profiles=[
            VectorSearchProfile(
                name="embedding_config",
                algorithm_configuration_name="hnsw_config",
            ),
        ],
    )

    # インデックス作成
    index_client = SearchIndexClient(endpoint=AZURE_SEARCH_SERVICE_ENDPOINT, credential=credential)
    if index_name not in index_client.list_index_names():
        index = SearchIndex(
            name=index_name,
            fields=fields,
            vector_search=vector_search,
            semantic_search=semantic_search,
        )
        print(f"Creating {index_name} search index")
        result = index_client.create_or_update_index(index) 
        print(f' {result.name} created')
    else:
        print(f"Search index {index_name} already exists")


def upload_blobs(path_file):
    """
    Azure Blob Storage にアップロード
    """
    
    # Azure Active Directory (Azure AD) 認証
    credential = DefaultAzureCredential()
    blob_service_client = BlobServiceClient(account_url=f"https://{os.getenv('AZURE_STORAGE_ACCOUNT')}.blob.core.windows.net/", credential=credential)
    
    blob_container = blob_service_client.get_container_client(os.getenv("CONTAINER_NAME"))
    if not blob_container.exists():
        blob_container.create_container()

    # ページ分割せずにそのままアップロードする
    blob_name = os.path.basename(path_file)
    with open(path_file, "rb") as data:
        blob_container.upload_blob(blob_name, data, overwrite=True)


def get_document_text(path_file):
    """
    Azure AI Document Intelligence を利用して帳票を OCR
    PDFのOCRに用いる[レイアウトモデル]`prebuilt-layout`は、高度な機械学習ベースのドキュメント分析APIです。
    これを使用すると、さまざまな形式のドキュメントを受け取り、ドキュメントの構造化されたデータ表現を返すことができます。
    これは、Microsoftの強力な光学式文字認識 (OCR) 機能の強化バージョンと、ディープラーニングモデルを組み合わせ、
    テキスト、テーブル、選択マーク、ドキュメント構造を抽出します。
    """
    
    def table_to_html(table):
        table_html = "<table>"
        rows = [sorted([cell for cell in table.cells if cell.row_index == i], key=lambda cell: cell.column_index) for i in range(table.row_count)]
        for row_cells in rows:
            table_html += "<tr>"
            for cell in row_cells:
                tag = "th" if (cell.kind == "columnHeader" or cell.kind == "rowHeader") else "td"
                cell_spans = ""
                if cell.column_span > 1: cell_spans += f" colSpan={cell.column_span}"
                if cell.row_span > 1: cell_spans += f" rowSpan={cell.row_span}"
                table_html += f"<{tag}{cell_spans}>{html.escape(cell.content)}</{tag}>"
            table_html +="</tr>"
        table_html += "</table>"
        return table_html

    offset = 0
    page_map = []

    print(f"Extracting text from '{path_file}' using Azure AI Document Intelligence")
    form_recognizer_client = DocumentAnalysisClient(endpoint=AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT, credential=document_intelligence_creds, headers={"x-ms-useragent": "azure-search-chat-demo/1.0.0"})
    with open(path_file, "rb") as f:
        poller = form_recognizer_client.begin_analyze_document("prebuilt-layout", document = f)
    form_recognizer_results = poller.result()

    for page_num, page in enumerate(form_recognizer_results.pages):
        tables_on_page = [table for table in form_recognizer_results.tables if table.bounding_regions[0].page_number == page_num + 1]

        # mark all positions of the table spans in the page
        page_offset = page.spans[0].offset
        page_length = page.spans[0].length
        table_chars = [-1]*page_length
        for table_id, table in enumerate(tables_on_page):
            for span in table.spans:
                # replace all table spans with "table_id" in table_chars array
                for i in range(span.length):
                    idx = span.offset - page_offset + i
                    if idx >=0 and idx < page_length:
                        table_chars[idx] = table_id

        # build page text by replacing characters in table spans with table html
        page_text = ""
        added_tables = set()
        for idx, table_id in enumerate(table_chars):
            if table_id == -1:
                page_text += form_recognizer_results.content[page_offset + idx]
            elif table_id not in added_tables:
                page_text += table_to_html(tables_on_page[table_id])
                added_tables.add(table_id)

        page_text += " "
        page_map.append((page_num, offset, page_text))
        offset += len(page_text) # 現在処理しているページのテキストが開始する位置

    return page_map


def split_text(page_map, filename, category):
    """
    チャンク分割
    
    Return: 
        generator object
    """
    
    #//$//
    
    # 全文を1つのチャンクとして返す
    if category == 'whole-type':
        all_text = "".join(p[2] for p in page_map)
        yield (all_text, 0)
        return
    
    # ページ単位での分割
    if category == 'ppt-type' or category == 'img-type':
        for page_num, (_, _, content) in enumerate(page_map):
            yield (content, page_num)
        return
    
    #//$//
    
    #####
    MAX_SECTION_LENGTH = 1000       # テキストを分割する際の最大セクション長
    SENTENCE_SEARCH_LIMIT = 100     # セクションの終端を決定する際に、句点(ピリオド、感嘆符、疑問符など)を探す最大範囲を指定する.
                                    # セクションの終端がMAX_SECTION_LENGTHに達した後、この範囲内で句点を探し、文の自然な区切りでセクションを終了させる.
    SECTION_OVERLAP = 100           # オーバーラップ長
    #####
    
    SENTENCE_ENDINGS = [".", "!", "?"]
    WORDS_BREAKS = [",", ";", ":", " ", "(", ")", "[", "]", "{", "}", "\t", "\n"]
    print(f"Splitting '{filename}' into sections")

    def find_page(offset):
        num_pages = len(page_map)
        for i in range(num_pages - 1):
            if offset >= page_map[i][1] and offset < page_map[i + 1][1]:
                return i
        return num_pages - 1

    all_text = "".join(p[2] for p in page_map)
    length = len(all_text)
    start = 0
    end = length
    while start + SECTION_OVERLAP < length:
        last_word = -1
        end = start + MAX_SECTION_LENGTH

        if end > length:
            end = length
        else:
            # Try to find the end of the sentence
            while end < length and (end - start - MAX_SECTION_LENGTH) < SENTENCE_SEARCH_LIMIT and all_text[end] not in SENTENCE_ENDINGS:
                if all_text[end] in WORDS_BREAKS:
                    last_word = end
                end += 1
            if end < length and all_text[end] not in SENTENCE_ENDINGS and last_word > 0:
                end = last_word # Fall back to at least keeping a whole word
        if end < length:
            end += 1

        # Try to find the start of the sentence or at least a whole word boundary
        last_word = -1
        while start > 0 and start > end - MAX_SECTION_LENGTH - 2 * SENTENCE_SEARCH_LIMIT and all_text[start] not in SENTENCE_ENDINGS:
            if all_text[start] in WORDS_BREAKS:
                last_word = start
            start -= 1
        if all_text[start] not in SENTENCE_ENDINGS and last_word > 0:
            start = last_word
        if start > 0:
            start += 1

        section_text = all_text[start:end]
        yield (section_text, find_page(start))

        last_table_start = section_text.rfind("<table")
        if (last_table_start > 2 * SENTENCE_SEARCH_LIMIT and last_table_start > section_text.rfind("</table")):
            # If the section ends with an unclosed table, we need to start the next section with the table.
            # If table starts inside SENTENCE_SEARCH_LIMIT, we ignore it, as that will cause an infinite loop for tables longer than MAX_SECTION_LENGTH
            # If last table starts inside SECTION_OVERLAP, keep overlapping
            print(f"Section ends with unclosed table, starting next section with the table at page {find_page(start)} offset {start} table start {last_table_start}")
            start = min(end - SECTION_OVERLAP, start + last_table_start)
        else:
            start = end - SECTION_OVERLAP

    if start + SECTION_OVERLAP < end:
        yield (all_text[start:end], find_page(start))


def create_fields(filename, page_map, use_vectors, category):
    """
    フィールド作成
    
    Return: 
        generator object
    """
    
    #
    # ファイル検索用インデックス
    #
    if category == "whole-type":
    
        file_id = filename_to_id(filename)
        for i, (content, pagenum) in enumerate(split_text(page_map, filename, category)):
            
            # クレンジング(改行コードを除去)
            content = content.replace('\n', ' ')
            
            if category != 'whole-type':
                raise Exception("Unknown category")
            
            #
            # filekey
            #
            filekey = generate_filekey(filename)
            
            #
            # summary
            #
            summary = generate_text_summary(content)
            
            #
            # keyphrases, internalterms
            #
            keyphrases, internalterms = generate_keyphrases_internalterms(content)
            
            #
            # assumedquestion
            #
            dic_assumedquestion = generate_assumedquestion(content)
            assumedquestion_general = dic_assumedquestion.get("general", "")
            assumedquestion_professional = dic_assumedquestion.get("professional", "")
            assumedquestion_comprehensive = dic_assumedquestion.get("comprehensive", "")
            
            #
            # emb_summary
            #
            emb_summary = generate_text_embedding_openai(summary)  # OpenAI Embedding (1536次元)
            # emb_summary = generate_text_embedding_aivision(summary)  # Azure AI Vision Embedding (1024次元)
            
            #
            # emb_keyphrases
            #
            emb_keyphrases = generate_text_embedding_openai(keyphrases)  # OpenAI Embedding (1536次元)
            
            #
            # emb_assumedquestion
            #
            emb_assumedquestion_general = generate_text_embedding_openai(assumedquestion_general)  # OpenAI Embedding (1536次元)
            emb_assumedquestion_professional = generate_text_embedding_openai(assumedquestion_professional)  # OpenAI Embedding (1536次元)
            emb_assumedquestion_comprehensive = generate_text_embedding_openai(assumedquestion_comprehensive)  # OpenAI Embedding (1536次元)
            
            #
            # yield
            #
            section = {
                "id": f"{file_id}-page-{i}",
                "sourcefile": filename,
                "filekey": filekey,
                "category": category,
                
                "content": content,
                "summary": summary,
                
                "keyphrases": keyphrases,
                "internalterms": internalterms,
                "assumedquestion_general": assumedquestion_general,
                "assumedquestion_professional": assumedquestion_professional,
                "assumedquestion_comprehensive": assumedquestion_comprehensive,
                
                "emb_summary": emb_summary,
                "emb_keyphrases": emb_keyphrases,
                "emb_assumedquestion_general": emb_assumedquestion_general,
                "emb_assumedquestion_professional": emb_assumedquestion_professional,
                "emb_assumedquestion_comprehensive": emb_assumedquestion_comprehensive,
            }
            
            yield section
     
    #       
    # チャンク検索用インデックス
    #
    elif category == "ppt-type" or category == "word-type" or category == "img-type":

        file_id = filename_to_id(filename)
        for i, (content, pagenum) in enumerate(split_text(page_map, filename, category)):
            
            # クレンジング(改行コードを除去)
            content = content.replace('\n', ' ')
            
            #
            # sourcepage
            #
            if category == 'word-type' or category == 'ppt-type':
                sourcepage = f"{filename}#page={pagenum+1}"
            elif category == 'img-type':
                body = filename.split('_page_')[0]
                page = filename.split('_page_')[1].split('.png')[0]
                sourcepage = f"{body}.pdf#page={page}"
            else:
                raise Exception("Unknown category")
        
            #
            # filekey
            #
            filekey = generate_filekey(filename)
            
            #
            # summary
            #
            if category == 'word-type' or category == 'ppt-type':
                summary = generate_text_summary(content)
            elif category == 'img-type':
                path_img = os.path.join('data-process','03-png-pages',filename)
                summary = generate_image_summary(path_img)
            else:
                raise Exception("Unknown category")
            
            #
            # keyphrases, internalterms
            #
            keyphrases, internalterms = generate_keyphrases_internalterms(content)
            
            #
            # assumedquestion
            #
            text = content if category != 'img-type' else summary
            dic_assumedquestion = generate_assumedquestion(text)
            assumedquestion_general = dic_assumedquestion.get("general", "")
            assumedquestion_professional = dic_assumedquestion.get("professional", "")
            assumedquestion_comprehensive = dic_assumedquestion.get("comprehensive", "")
            
            #
            # embedding
            #
            if category == 'word-type' or category == 'ppt-type':
                # embedding = generate_text_embedding_openai(content)  # OpenAI Embedding (1536次元)
                embedding = generate_text_embedding_aivision(content)  # Azure AI Vision Embedding (1024次元)
            elif category == 'img-type':
                path_img = os.path.join('data-process','03-png-pages',filename)
                embedding = generate_image_embedding_aivision(path_img)  # Azure AI Vision Embedding (1024次元)
            else:
                raise Exception("Unknown category")
            
            #
            # emb_summary
            #
            emb_summary = generate_text_embedding_openai(summary)  # OpenAI Embedding (1536次元)
            # emb_summary = generate_text_embedding_aivision(summary)  # Azure AI Vision Embedding (1024次元)
            
            #
            # emb_keyphrases
            #
            emb_keyphrases = generate_text_embedding_openai(keyphrases)  # OpenAI Embedding (1536次元)
            
            #
            # emb_assumedquestion
            #
            emb_assumedquestion_general = generate_text_embedding_openai(assumedquestion_general)  # OpenAI Embedding (1536次元)
            emb_assumedquestion_professional = generate_text_embedding_openai(assumedquestion_professional)  # OpenAI Embedding (1536次元)
            emb_assumedquestion_comprehensive = generate_text_embedding_openai(assumedquestion_comprehensive)  # OpenAI Embedding (1536次元)
            
            #
            # yield
            #
            section = {
                "id": f"{file_id}-page-{i}",
                "sourcefile": filename,
                "sourcepage": sourcepage,
                "filekey": filekey,
                # "metadata": json.dumps({"page": pagenum, "sourcepage": sourcepage}),
                "category": category,
                
                "content": content,
                "summary": summary,
                
                "keyphrases": keyphrases,
                "internalterms": internalterms,
                "assumedquestion_general": assumedquestion_general,
                "assumedquestion_professional": assumedquestion_professional,
                "assumedquestion_comprehensive": assumedquestion_comprehensive,
                
                "embedding": embedding,
                "emb_summary": emb_summary,
                "emb_keyphrases": emb_keyphrases,
                "emb_assumedquestion_general": emb_assumedquestion_general,
                "emb_assumedquestion_professional": emb_assumedquestion_professional,
                "emb_assumedquestion_comprehensive": emb_assumedquestion_comprehensive,
            }
            
            yield section


def index_sections(index_name, filename, sections, index_name_all=None):
    """
    インデックス作成/登録
    """
    search_client = SearchClient(
        endpoint=AZURE_SEARCH_SERVICE_ENDPOINT, index_name=index_name, credential=credential
    )
    # 横断検索用
    search_client_for_all = SearchClient(
        endpoint=AZURE_SEARCH_SERVICE_ENDPOINT, index_name=index_name_all, credential=credential
    )
    
    i = 0
    batch = []
    for s in sections:
        batch.append(s)
        i += 1
        if i % 1000 == 0:
            results = search_client.upload_documents(documents=batch)
            _ = search_client_for_all.upload_documents(documents=batch) # 横断検索用
            succeeded = sum([1 for r in results if r.succeeded])
            print(f"\tIndexed {len(results)} sections, {succeeded} succeeded")
            batch = []

    if len(batch) > 0:
        results = search_client.upload_documents(documents=batch)
        _ = search_client_for_all.upload_documents(documents=batch) # 横断検索用
        succeeded = sum([1 for r in results if r.succeeded])
        print(f"\tIndexed {len(results)} sections, {succeeded} succeeded")
        

#####################################################################################################################
# 実行
#####################################################################################################################
start_time = time.time()

# ***** 横断検索用インデックス ***** #
# 横断検索用インデックスを定義
INDEXNAME_ALL_CHUNK = "index-all"  # チャンク単位インデックス
INDEXNAME_ALL_FILE = f"{INDEXNAME_ALL_CHUNK}-file"  # ファイル単位インデックス
# インデックス作成
print(f"*** Create Search Index of {INDEXNAME_ALL_CHUNK} and {INDEXNAME_ALL_FILE} ***")
create_index(INDEXNAME_ALL_CHUNK, unit="chunk")
create_index(INDEXNAME_ALL_FILE, unit="file")


# ***** インデックス ループ ***** #
lst_path_index_unit_folder = glob.glob("./data/*") # dataフォルダ内のインデックス作成単位のフォルダのパスのリストを取得
for path_index_unit_folder in lst_path_index_unit_folder:
    foldername = os.path.basename(path_index_unit_folder) # フォルダ名
    # index-setting.json を探して見つかれば辞書に格納
    if os.path.join(path_index_unit_folder, "index-setting.json"):
        with open(os.path.join(path_index_unit_folder, "index-setting.json"), "r", encoding="utf-8") as f:
            dic_setting = json.load(f)
    else:
        print(f"No index-setting.json in {foldername}")
        continue
    
    indexname_chunk = dic_setting["index_name"] # index-setting.json から チャンク単位インデックス名 を取得
    indexname_file = f"{indexname_chunk}-file"  # ファイル単位インデックス名 を定義
    
    # インデックス作成
    print(f"*** Create Search Index of {indexname_chunk} and {indexname_file} in {foldername} ***")
    create_index(indexname_chunk, unit="chunk")
    create_index(indexname_file, unit="file")
    
    
    # ***** ファイル ループ ***** #
    lst_orgfilenames = list(dic_setting["chunk_type"].keys()) # 条件① index-setting.json 内に記載のファイル名のリストを取得
    for orgfilename in lst_orgfilenames:
        
        # 下記3条件を全て満たす場合のみインデックスが追加される
        # 条件① index-setting.json に記載済み
        # 条件② data/カテゴリ配下のファイルが存在する (事前にdata-process以下への反映も必要)
        # 条件③ 既存インデックスに登録済みでない

        # 条件②
        if not os.path.exists(os.path.join(path_index_unit_folder, orgfilename)):
            continue
        
        # 条件③
        filekey = generate_filekey(orgfilename)
        search_client = SearchClient(
            endpoint=AZURE_SEARCH_SERVICE_ENDPOINT, index_name=indexname_chunk, credential=credential
        )
        results = search_client.search(search_text="", filter=f"filekey eq '{filekey}'")
        flag_filekey = any(results)
        if flag_filekey:
            continue
        
        print(f"*** Processing '{orgfilename}' ***")
        orgfilebody = orgfilename.split(".")[0]
        category_setting = dic_setting["chunk_type"][orgfilename]
        
        def process(index_name, category, path_file, index_name_all):
            try:
                if category != "whole-type":
                    upload_blobs(path_file)
                page_map = get_document_text(path_file)
                sections = create_fields(
                    os.path.basename(path_file), page_map, False, category
                )
                index_sections(index_name, os.path.basename(path_file), sections, index_name_all)
            except Exception as e:
                print(f"\tGot an error while reading {path_file} -> {e} --> skipping file")
        
        # テキストチャンク (インデックス:チャンク, category:word-type,ppt-type)
        lst_path_file = glob.glob(f"./data-process/01-pdf/{orgfilebody}.pdf") + glob.glob(f"./data-process/01-pdf/{orgfilebody}_type_*.pdf")
        path_file = lst_path_file[0] if len(lst_path_file) == 1 else sys.exit(f"unexpected file number of {orgfilebody}: {len(lst_path_file)}")
        process(
            index_name=indexname_chunk, 
            category=category_setting,
            path_file=path_file,
            index_name_all=INDEXNAME_ALL_CHUNK
        )
        
        # ページ画像 (インデックス:チャンク, category:img-type)
        lst_path_file = natsorted(glob.glob(f"./data-process/03-png-pages/{orgfilebody}_type_*.png") + glob.glob(f"./data-process/03-png-pages/{orgfilebody}_page_*.png")) # ページ画像なので複数ファイル
        for path_file in lst_path_file:
            process(
                index_name=indexname_chunk,
                category="img-type",
                path_file=path_file,
                index_name_all=INDEXNAME_ALL_CHUNK
            )
        
        #  ファイル (インデックス:ファイル, category:whole-type)
        lst_path_file = glob.glob(f"./data-process/01-pdf/{orgfilebody}.pdf") + glob.glob(f"./data-process/01-pdf/{orgfilebody}_type_*.pdf")
        path_file = lst_path_file[0] if len(lst_path_file) == 1 else sys.exit(f"unexpected file number of {orgfilebody}")
        process(
            index_name=indexname_file, 
            category="whole-type",
            path_file=path_file,
            index_name_all=INDEXNAME_ALL_FILE
        )


print(f"Elapsed time: {elapsed_time(start_time)}")