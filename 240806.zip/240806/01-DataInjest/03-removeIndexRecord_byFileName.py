import glob
import os
import sys
import time
import json

from azure.search.documents import SearchClient
from azure.core.credentials import AzureKeyCredential

from azure.identity import DefaultAzureCredential
from azure.storage.blob import BlobServiceClient

from dotenv import load_dotenv
load_dotenv()


# Azure AI Search
AZURE_SEARCH_SERVICE_ENDPOINT: str = os.getenv("AZURE_SEARCH_SERVICE_ENDPOINT")
AZURE_SEARCH_SERVICE_ADMIN_KEY: str = os.getenv("AZURE_SEARCH_SERVICE_ADMIN_KEY")
search_analyzer_name: str = "ja.lucene"
credential_search = AzureKeyCredential(AZURE_SEARCH_SERVICE_ADMIN_KEY)

# Blob Storage
# Azure Active Directory (Azure AD) 認証
credential_blob = DefaultAzureCredential()
blob_service_client = BlobServiceClient(account_url=f"https://{os.getenv('AZURE_STORAGE_ACCOUNT')}.blob.core.windows.net/", credential=credential_blob)
container_name = os.getenv("CONTAINER_NAME")  # コンテナ名


def remove_from_index(filekey, indexname):
    print(f"Removing sections from '{filekey or '<all>'}' from search index '{indexname}'")
    search_client = SearchClient(endpoint=AZURE_SEARCH_SERVICE_ENDPOINT,
                                    index_name=indexname,
                                    credential=credential_search)
    while True:
        filter = None if filekey is None else f"filekey eq '{filekey}'"
        r = search_client.search("", filter=filter, top=1000, include_total_count=True)
        if r.get_count() == 0:
            break
        r = search_client.delete_documents(documents=[{ "id": d["id"] } for d in r])
        print(f"\tRemoved {len(r)} sections from index")
        time.sleep(2) # It can take a few seconds for search results to reflect changes, so wait a bit
        
        
# 削除するファイル(拡張子を含めても含めなくてもOK) と インデックス名(指定せずにNoneでもOK) を指定
dic_removefile_indexname = {
    # "DDOG_Q3_earnings_deck": "index-itmanual",
    # "講座案内.doc": None,
    "出張申請手順.docx": None,
    "情報管理規定.docx": None,
    # "源範頼 - Wikipedia.pdf": None,
    # "softbank_sustainability_report_2023.pdf": None,
    # "Softbank2024年3月期第1四半期決算説明会.pdf": "index-office",
}

# フィルタリングされたファイル名でインデックスから削除
for removefile, indexname in dic_removefile_indexname.items():
    
    # 拡張子を含むものは除外
    filekey = removefile.split('.')[0] if '.' in removefile else removefile
    
    # インデックス名がNoneの場合は index-setting から検索
    if indexname is None:
        lst_path_index_unit_folder = glob.glob("./data/*") # dataフォルダ内のインデックス作成単位のフォルダのパスのリストを取得
        for path_index_unit_folder in lst_path_index_unit_folder:
            foldername = os.path.basename(path_index_unit_folder) # フォルダ名
            # index-setting.json を探して見つかれば辞書に格納
            if os.path.join(path_index_unit_folder, "index-setting.json"):
                with open(os.path.join(path_index_unit_folder, "index-setting.json"), "r", encoding="utf-8") as f:
                    dic_setting = json.load(f)
            else:
                continue
            lst_orgfilenames = list(dic_setting["chunk_type"].keys()) # index-setting.json 内に記載のファイル名のリストを取得
            lst_orgfilekey = [f.split('.')[0] for f in lst_orgfilenames] # 拡張子を除去
            if filekey in lst_orgfilekey:
                indexname = dic_setting["index_name"]
                break
            else:
                continue
        if indexname is None:
            raise Exception(f"{removefile} が このプログラム でも index-setting.json でも 指定されていません。いずれかの方法でインデックス名を指定してください。")
        
    
    # インデックス削除実行
    remove_from_index(filekey, indexname)
    remove_from_index(filekey, 'index-all')
    remove_from_index(filekey, f"{indexname}-file")
    remove_from_index(filekey, 'index-all-file')


    #
    # Blob Storage のコンテナから対象ファイルを削除
    #
    print(f"Removing {filekey} from Blob Storage")

    # コンテナ内の全Blobを取得
    blob_list = blob_service_client.get_container_client(container_name).list_blobs()
    # filekeyの文字列を含むBlobのみ
    blob_list = [blob for blob in blob_list if filekey in blob.name]

    # 各Blobを削除
    for blob in blob_list:
        blob_client = blob_service_client.get_blob_client(container_name, blob.name)
        blob_client.delete_blob()
        print(f"\tRemoved {blob.name} from Blob Storage")