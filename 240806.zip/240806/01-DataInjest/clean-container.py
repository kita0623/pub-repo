import os
from azure.identity import DefaultAzureCredential
from azure.storage.blob import BlobServiceClient
from dotenv import load_dotenv
load_dotenv()


# キーベースの認証
# blob_service_client = BlobServiceClient.from_connection_string(os.environ["AZURE_STORAGE_CONNECTION_STRING"])

# Azure Active Directory (Azure AD) 認証
credential = DefaultAzureCredential()
blob_service_client = BlobServiceClient(account_url=f"https://{os.getenv('AZURE_STORAGE_ACCOUNT')}.blob.core.windows.net/", credential=credential)

container_name = os.getenv("CONTAINER_NAME")

# コンテナ内の全Blobを取得
blob_list = blob_service_client.get_container_client(container_name).list_blobs()

# 各Blobを削除
for blob in blob_list:
    blob_client = blob_service_client.get_blob_client(container_name, blob.name)
    blob_client.delete_blob()