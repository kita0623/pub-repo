import dataclasses
import io
import json
import logging
import mimetypes
import os
from pathlib import Path
from typing import Any, AsyncGenerator, Dict, Union, cast, List, Tuple

from azure.core.credentials import AzureKeyCredential
from azure.core.credentials_async import AsyncTokenCredential
from azure.core.exceptions import ResourceExistsError, ResourceNotFoundError 
from azure.identity.aio import DefaultAzureCredential, get_bearer_token_provider
from azure.keyvault.secrets.aio import SecretClient
from azure.monitor.opentelemetry import configure_azure_monitor
from azure.search.documents.aio import SearchClient
from azure.search.documents.indexes.aio import SearchIndexClient
from azure.storage.blob.aio import ContainerClient
from azure.storage.blob.aio import StorageStreamDownloader as BlobDownloader
from azure.storage.filedatalake.aio import FileSystemClient
from azure.storage.filedatalake.aio import StorageStreamDownloader as DatalakeDownloader
from openai import AsyncAzureOpenAI, AsyncOpenAI
from opentelemetry.instrumentation.aiohttp_client import AioHttpClientInstrumentor
from opentelemetry.instrumentation.asgi import OpenTelemetryMiddleware
from opentelemetry.instrumentation.httpx import (
    HTTPXClientInstrumentor,
)
from opentelemetry.instrumentation.openai import OpenAIInstrumentor
from quart import (
    Blueprint,
    Quart,
    abort,
    current_app,
    jsonify,
    make_response,
    request,
    send_file,
    send_from_directory,
)
from quart_cors import cors

from approaches.approach import Approach
from approaches.chatreadretrieveread import ChatReadRetrieveReadApproach
from approaches.chatreadretrievereadvision import ChatReadRetrieveReadVisionApproach
from approaches.retrievethenread import RetrieveThenReadApproach
from approaches.retrievethenreadvision import RetrieveThenReadVisionApproach
from config import (
    CONFIG_ASK_APPROACH,
    CONFIG_ASK_VISION_APPROACH,
    CONFIG_AUTH_CLIENT,
    CONFIG_BLOB_CONTAINER_CLIENT,
    CONFIG_CHAT_APPROACH,
    CONFIG_CHAT_VISION_APPROACH,
    CONFIG_GPT4V_DEPLOYED,
    CONFIG_INGESTER,
    CONFIG_OPENAI_CLIENT,
    CONFIG_SEARCH_CLIENT,
    CONFIG_SEMANTIC_RANKER_DEPLOYED,
    CONFIG_USER_BLOB_CONTAINER_CLIENT,
    CONFIG_USER_UPLOAD_ENABLED,
    CONFIG_VECTOR_SEARCH_ENABLED,
)
from core.authentication import AuthenticationHelper
from decorators import authenticated, authenticated_path
from error import error_dict, error_response
from prepdocs import (
    clean_key_if_exists,
    setup_embeddings_service,
    setup_file_processors,
    setup_search_info,
)
from prepdocslib.filestrategy import UploadUserFileStrategy
from prepdocslib.listfilestrategy import File



import re
import base64
from tenacity import retry, stop_after_attempt, wait_random_exponential

from azure.search.documents.indexes.models import (
    ExhaustiveKnnAlgorithmConfiguration,
    ExhaustiveKnnParameters,
    HnswAlgorithmConfiguration,
    HnswParameters,
    SearchField,
    SearchFieldDataType,
    SearchIndex,
    SearchableField,
    SemanticConfiguration,
    SemanticField,
    SemanticPrioritizedFields,
    SemanticSearch,
    SimpleField,
    VectorSearch,
    VectorSearchAlgorithmConfiguration,
    VectorSearchAlgorithmKind,
    VectorSearchAlgorithmMetric,
    VectorSearchProfile,
)
from azure.search.documents.models import VectorizedQuery
from azure.data.tables.aio import TableServiceClient


MODE_RESPONSE = "LLM"  # 直近の回答のモード ("LLM", "CACHE_DB", "FAQ_DB")
LST_FLAG_REGENERATE = []  # 直近2回分のflag_regenerate


async def get_keyphrases(text: str) -> str:
    openai_client = current_app.config[CONFIG_OPENAI_CLIENT]
    messages= [{"role": "user", "content": f"""
    下記の本文章からキーフレーズを抽出してしてください。回答はカンマ区切りで返してください。
    
    ### 文章例 ###
    RAGとファインチューニングの推奨用途をそれぞれ教えてください
    
    ### 回答例 ###
    RAG,ファインチューニング,推奨用途
    
    ### 本文章 ###
    {text}
    """}]
    
    response = await openai_client.chat.completions.create(
        model=os.getenv("AZURE_OPENAI_GPT4_TURBO_20240409_DEPLOYMENT"),
        messages= messages,
        temperature=0, # 再現性を高めるためtemperature=0
    )
    response_content = response.choices[0].message.content
    lst_term = [term.strip() for term in response_content.split(',')]
    lst_term = sorted(lst_term) # 一致率を上げるためソート
    keyphrases = ",".join(lst_term)
    return keyphrases


async def replace_ambiguous_terms(text: str, history: List[Tuple[str, str]]) -> str:
    
    # 会話履歴の文字列を作成
    history_text = "\n".join(["質問: {}\n回答: {}".format(
        q.replace('\n', ' ').strip(),
        a['choices'][0]['message']['content'].replace('\n', ' ').strip()
    ) for q, a in history])
    # ) for q, a in history[:-1]]) # 直近の質問文/回答文自身も含めた方が精度が良いため不採用
    
    openai_client = current_app.config[CONFIG_OPENAI_CLIENT]
    messages= [{"role": "user", "content": f"""
    下記の本質問文において、指示語などを含めて指示している対象が不明な用語があれば、会話履歴を参考に置換してください。
    指示している対象が不明な用語以外は元の質問文を変形せずにそのまま返してください。
    指示している対象が不明な用語がなければ、元の質問文をそのまま返してください。
    
    ### 会話履歴 ###
    {history_text}
    
    ### 本質問文 ###
    {text}
    """}]
    
    response = await openai_client.chat.completions.create(
        # model=os.getenv("AZURE_OPENAI_GPT4_TURBO_20240409_DEPLOYMENT"),
        model=os.getenv("AZURE_OPENAI_GPT4_DEPLOYMENT"),
        messages= messages,
        temperature=0, # 再現性を高めるためtemperature=0
    )
    response_content = response.choices[0].message.content
    
    return response_content


# SPLITTER = "----------------------------------------------------"
# SPLITTER = "----------------------------------------------------\n\n回答 :"
SPLITTER = "回答 :"


async def add_answer_headmessage(answer, question, response_by):
    """
    フロントエンド側での表示用に回答文に補足部を追加
    """
    head_message = f"""
({response_by}から参照した質問と回答)

質問 : {question}
""".strip()
    answer = head_message + '\n\n' + SPLITTER + '\n\n' + answer
    return answer


async def remove_answer_headmessage(answer):
    """
    ・バックエンド側での処理のため回答文の補足部を除去
    ・キャッシュDBやFAQDBに登録されている質問を抽出
    """
    answer_onlyMain = answer.split(SPLITTER)[-1].strip()
    question_fmDB = answer.split(SPLITTER)[0].split('質問 :')[-1].strip()
    return answer_onlyMain, question_fmDB




bp = Blueprint("routes", __name__, static_folder="static")
# Fix Windows registry issue with mimetypes
mimetypes.add_type("application/javascript", ".js")
mimetypes.add_type("text/css", ".css")


@bp.route("/")
async def index():
    return await bp.send_static_file("index.html")


# Empty page is recommended for login redirect to work.
# See https://github.com/AzureAD/microsoft-authentication-library-for-js/blob/dev/lib/msal-browser/docs/initialization.md#redirecturi-considerations for more information
@bp.route("/redirect")
async def redirect():
    return ""


@bp.route("/favicon.ico")
async def favicon():
    return await bp.send_static_file("favicon.ico")


@bp.route("/assets/<path:path>")
async def assets(path):
    return await send_from_directory(Path(__file__).resolve().parent / "static" / "assets", path)


@bp.route("/content/<path>")
@authenticated_path
async def content_file(path: str, auth_claims: Dict[str, Any]):
    """
    Serve content files from blob storage from within the app to keep the example self-contained.
    *** NOTE *** if you are using app services authentication, this route will return unauthorized to all users that are not logged in
    if AZURE_ENFORCE_ACCESS_CONTROL is not set or false, logged in users can access all files regardless of access control
    if AZURE_ENFORCE_ACCESS_CONTROL is set to true, logged in users can only access files they have access to
    This is also slow and memory hungry.
    """
    # Remove page number from path, filename-1.txt -> filename.txt
    # This shouldn't typically be necessary as browsers don't send hash fragments to servers
    if path.find("#page=") > 0:
        path_parts = path.rsplit("#page=", 1)
        path = path_parts[0]
    logging.info("Opening file %s", path)
    blob_container_client: ContainerClient = current_app.config[CONFIG_BLOB_CONTAINER_CLIENT]
    blob: Union[BlobDownloader, DatalakeDownloader]
    try:
        blob = await blob_container_client.get_blob_client(path).download_blob()
    except ResourceNotFoundError:
        logging.info("Path not found in general Blob container: %s", path)
        if current_app.config[CONFIG_USER_UPLOAD_ENABLED]:
            try:
                user_oid = auth_claims["oid"]
                user_blob_container_client = current_app.config[CONFIG_USER_BLOB_CONTAINER_CLIENT]
                user_directory_client: FileSystemClient = user_blob_container_client.get_directory_client(user_oid)
                file_client = user_directory_client.get_file_client(path)
                blob = await file_client.download_file()
            except ResourceNotFoundError:
                logging.exception("Path not found in DataLake: %s", path)
                abort(404)
        else:
            abort(404)
    if not blob.properties or not blob.properties.has_key("content_settings"):
        abort(404)
    mime_type = blob.properties["content_settings"]["content_type"]
    if mime_type == "application/octet-stream":
        mime_type = mimetypes.guess_type(path)[0] or "application/octet-stream"
    blob_file = io.BytesIO()
    await blob.readinto(blob_file)
    blob_file.seek(0)
    return await send_file(blob_file, mimetype=mime_type, as_attachment=False, attachment_filename=path)


class JSONEncoder(json.JSONEncoder):
    def default(self, o):
        if dataclasses.is_dataclass(o):
            return dataclasses.asdict(o)
        return super().default(o)


async def format_as_ndjson(r: AsyncGenerator[dict, None]) -> AsyncGenerator[str, None]:
    try:
        async for event in r:
            yield json.dumps(event, ensure_ascii=False, cls=JSONEncoder) + "\n"
    except Exception as error:
        logging.exception("Exception while generating response stream: %s", error)
        yield json.dumps(error_dict(error))


@bp.route("/chat", methods=["POST"])
@authenticated
async def chat(auth_claims: Dict[str, Any]):
    if not request.is_json:
        return jsonify({"error": "request must be json"}), 415
    request_json = await request.get_json()
    context = request_json.get("context", {})
    context["auth_claims"] = auth_claims
    
    # 回答再生成において、直近でキャッシュDBやFAQDBを使用した場合は、それらを除外して別モードで実行する
    global MODE_RESPONSE
    global MODE_RESPONSE_OLD
    flag_regenerate = context["overrides"]["flag_regenerate"]
    lst_mode_allowed = ["CACHE_DB", "FAQ_DB", "LLM"]
    if flag_regenerate:
        if MODE_RESPONSE=="CACHE_DB":
            lst_mode_allowed = ["FAQ_DB", "LLM"]
        elif MODE_RESPONSE=="FAQ_DB":
            lst_mode_allowed = ["LLM"]
        else:
            lst_mode_allowed = ["LLM"]
    
    # 再生成ボタン押下がトリガーでなくても、直近の回答でキャッシュDBやFAQDBを使用し、同じ質問がインプットされた場合は、再生成フラグをTrueにする 
    # (直近の質問/回答を履歴からの削除対象とするため)
    # 履歴から重複分を除外することを目的としているため、この処理はこの位置である必要がある
    if MODE_RESPONSE in ["CACHE_DB", "FAQ_DB"] and request_json["messages"][-1]["content"] == request_json["messages"][-3]["content"]:
        flag_regenerate = True
    
    # 回答再生成において、同一質問の再生成前の質問/回答が履歴に入ると、再生成の結果に影響してしまうため、履歴から除外する
    global LST_FLAG_REGENERATE
    LST_FLAG_REGENERATE.append(flag_regenerate)
    # LST_FLAG_REGENERATEの要素がtrueとなっている要素のインデックスを取得
    idx_true_LST_FLAG_REGENERATE = [i for i, x in enumerate(LST_FLAG_REGENERATE) if x]
    # request_json['messages'] の削除する位置を指定
    idx_remove = [j for i in idx_true_LST_FLAG_REGENERATE for j in (2*(i-1), 2*(i-1)+1)]
    # 削除
    request_json['messages'] = [msg for i, msg in enumerate(request_json['messages']) if i not in idx_remove]
    
    # インデックス一覧を取得
    search_index_client = SearchIndexClient(
        endpoint=f"https://{os.getenv('AZURE_SEARCH_SERVICE')}.search.windows.net",
        credential=AzureKeyCredential(os.getenv('AZURE_SEARCH_SERVICE_ADMIN_KEY')),
    )
    indexes_itempaged = search_index_client.list_index_names()
    indexes_lst = [index async for index in indexes_itempaged]
    
    #######################################################
    # CasheDB からの回答
    #######################################################
    if context["overrides"]["use_cashe_db"] and "CACHE_DB" in lst_mode_allowed:
        index_name_casheDB = 'db-cashe'
        
        if index_name_casheDB in indexes_lst:
            search_client_casheDB = SearchClient(
                endpoint=f"https://{os.getenv('AZURE_SEARCH_SERVICE')}.search.windows.net",
                index_name=index_name_casheDB,
                credential=AzureKeyCredential(os.getenv('AZURE_SEARCH_SERVICE_ADMIN_KEY')),
            )
            question = request_json.get("messages")[-1].get("content")
            
            flag_cashe_filter1 = False
            flag_cashe_filter2 = False
            # フィルター1: 質問文が完全一致
            search_filter_results = await search_client_casheDB.search(search_text="", filter=f"question eq '{question}'")
            async for record in search_filter_results:
                question_fm_CasheDB = record["question"]
                answer_fm_CasheDB = record["answer"]
                flag_cashe_filter1 = True
            # フィルター2: キーフレーズが完全一致
            if not flag_cashe_filter1:
                keyphrases = await get_keyphrases(question)
                search_filter_results = await search_client_casheDB.search(search_text="", filter=f"keyphrases eq '{keyphrases}'")
                async for record in search_filter_results:
                    question_fm_CasheDB = record["question"]
                    answer_fm_CasheDB = record["answer"]
                    flag_cashe_filter2 = True
            # フィルター1かフィルター2が一致した場合は、CasheDBから取得した回答を返す
            if flag_cashe_filter1 or flag_cashe_filter2:
                MODE_RESPONSE = "CACHE_DB"
                answer_arranged = await add_answer_headmessage(
                    answer=answer_fm_CasheDB, 
                    question=question_fm_CasheDB, 
                    response_by="キャッシュDB", 
                )
                result = {}
                result['id'] = 'chatcmp-CasheDB'
                result['created'] = 0000000000
                result['model'] = 'gpt'
                result['object'] = 'chat.completions'
                result['system_fingerprint'] = 'CasheDB'
                result['usage'] = {
                    'prompt_tokens': -1,
                    'completion_tokens': -1,
                    'total_tokens': -1
                }
                result['choices'] = [{
                    'finish_reason': 'stop',
                    'index': 0,
                    'logprobs': None,
                    'message': {
                        'content': answer_arranged,
                        'role': 'assistant',
                        'function_call': None,
                        'tool_calls': None
                    },
                    'context': {
                        'data_points': {'text': []},
                        'thoughts': []
                    },
                    'session_state': None
                }]
                result['flagFromCasheFAQDB'] = True  # CasheDB や FAQDB からのデータであることを示すフラグを追加
                return jsonify(result)
    
    #######################################################
    # FAQDB からの回答
    #######################################################
    if context["overrides"]["use_faq_db"] and "FAQ_DB" in lst_mode_allowed:
        index_name_FAQDB = 'db-faq'
        
        if index_name_FAQDB in indexes_lst:
            search_client_FAQDB = SearchClient(
                endpoint=f"https://{os.getenv('AZURE_SEARCH_SERVICE')}.search.windows.net",
                index_name=index_name_FAQDB,
                credential=AzureKeyCredential(os.getenv('AZURE_SEARCH_SERVICE_ADMIN_KEY')),
            )
            question = request_json.get("messages")[-1].get("content")
            
            # 質問文のembedding作成
            async def before_retry_sleep(retry_state):
                print("Rate limited on the OpenAI embeddings API, sleeping before retrying...")

            @retry(wait=wait_random_exponential(min=15, max=60), stop=stop_after_attempt(15), before_sleep=before_retry_sleep)
            async def generate_text_embedding_openai(text):
                return (await aoai_client.embeddings.create(input=[text], model=os.getenv("AZURE_OPENAI_EMB_MODEL_DEPLOYMENT"))).data[0].embedding
            
            aoai_client = current_app.config[CONFIG_OPENAI_CLIENT]
            vector = await generate_text_embedding_openai(question)
            vector_query = VectorizedQuery(vector=vector, k_nearest_neighbors=None, fields="emb_question")
            
            # 検索
            results = await search_client_FAQDB.search(
                search_text=question, # 質問文が検索クエリ
                vector_queries=[vector_query],
                top=1,
                semantic_configuration_name="default" if context["overrides"]["use_faq_db_semantic_ranker"] else None, # "answer"フィールドに対して適用
                query_caption=None, # セマンティックキャプションはOFF
            )
            results = [result async for result in results]
            result_dic = results[0]
            
            question_fm_FAQDB = result_dic.get("question")
            answer_fm_FAQDB = result_dic.get("answer")
            search_score = result_dic.get("@search.score")
            
            if search_score > context["overrides"]["faq_db_search_score_threshold"]:
                MODE_RESPONSE = "FAQ_DB"
                answer_arranged = await add_answer_headmessage(
                    answer=answer_fm_FAQDB, 
                    question=question_fm_FAQDB, 
                    response_by="FAQDB", 
                )
                result = {}
                result['id'] = 'chatcmp-FAQDB'
                result['created'] = 0000000000
                result['model'] = 'gpt'
                result['object'] = 'chat.completions'
                result['system_fingerprint'] = 'FAQDB'
                result['usage'] = {
                    'prompt_tokens': -1,
                    'completion_tokens': -1,
                    'total_tokens': -1
                }
                result['choices'] = [{
                    'finish_reason': 'stop',
                    'index': 0,
                    'logprobs': None,
                    'message': {
                        'content': answer_arranged,
                        'role': 'assistant',
                        'function_call': None,
                        'tool_calls': None
                    },
                    'context': {
                        'data_points': {'text': []},
                        'thoughts': []
                    },
                    'session_state': None
                }]
                result['flagFromCasheFAQDB'] = True  # CasheDB や FAQDB からのデータであることを示すフラグを追加
                return jsonify(result)
    
    
    #フロントエンド側から取得したインデックス名を指定してインデックスクライアントを再作成
    index_name = context.get("overrides", {}).get("index_name", "")
    search_client = SearchClient(
        endpoint=f"https://{os.getenv('AZURE_SEARCH_SERVICE')}.search.windows.net",
        index_name=index_name,
        credential=AzureKeyCredential(os.getenv('AZURE_SEARCH_SERVICE_ADMIN_KEY')),
    )
    index_name_file = f"{index_name}-file"
    search_client_file = SearchClient(
        endpoint=f"https://{os.getenv('AZURE_SEARCH_SERVICE')}.search.windows.net",
        index_name=index_name_file,
        credential=AzureKeyCredential(os.getenv('AZURE_SEARCH_SERVICE_ADMIN_KEY')),
    )
    # 設定を上書き
    current_app.config[CONFIG_CHAT_APPROACH].search_client = search_client
    current_app.config[CONFIG_CHAT_APPROACH].search_client_file = search_client_file
    
    MODE_RESPONSE = "LLM"
    
    
    try:
        use_gpt4v = context.get("overrides", {}).get("use_gpt4v", False)
        approach: Approach
        if use_gpt4v and CONFIG_CHAT_VISION_APPROACH in current_app.config:
            approach = cast(Approach, current_app.config[CONFIG_CHAT_VISION_APPROACH])
        else:
            approach = cast(Approach, current_app.config[CONFIG_CHAT_APPROACH])

        result = await approach.run(
            request_json["messages"],
            stream=request_json.get("stream", False),
            context=context,
            session_state=request_json.get("session_state"),
        )
        
        # ストリーミングがOFFの場合
        if isinstance(result, dict):
            return jsonify(result)
        
        # ストリーミングがONの場合
        else:
            response = await make_response(format_as_ndjson(result))
            response.timeout = None  # type: ignore
            response.mimetype = "application/json-lines"
            return response
        
    except Exception as error:
        return error_response(error, "/chat")


# Send MSAL.js settings to the client UI
@bp.route("/auth_setup", methods=["GET"])
def auth_setup():
    auth_helper = current_app.config[CONFIG_AUTH_CLIENT]
    return jsonify(auth_helper.get_auth_setup_for_client())


@bp.route("/config", methods=["GET"])
def config():
    return jsonify(
        {
            "showGPT4VOptions": current_app.config[CONFIG_GPT4V_DEPLOYED],
            "showSemanticRankerOption": current_app.config[CONFIG_SEMANTIC_RANKER_DEPLOYED],
            "showVectorOption": current_app.config[CONFIG_VECTOR_SEARCH_ENABLED],
            "showUserUpload": current_app.config[CONFIG_USER_UPLOAD_ENABLED],
        }
    )


@bp.post("/upload")
@authenticated
async def upload(auth_claims: dict[str, Any]):
    request_files = await request.files
    if "file" not in request_files:
        # If no files were included in the request, return an error response
        return jsonify({"message": "No file part in the request", "status": "failed"}), 400

    user_oid = auth_claims["oid"]
    file = request_files.getlist("file")[0]
    user_blob_container_client: FileSystemClient = current_app.config[CONFIG_USER_BLOB_CONTAINER_CLIENT]
    user_directory_client = user_blob_container_client.get_directory_client(user_oid)
    try:
        await user_directory_client.get_directory_properties()
    except ResourceNotFoundError:
        current_app.logger.info("Creating directory for user %s", user_oid)
        await user_directory_client.create_directory()
    await user_directory_client.set_access_control(owner=user_oid)
    file_client = user_directory_client.get_file_client(file.filename)
    file_io = file
    file_io.name = file.filename
    file_io = io.BufferedReader(file_io)
    await file_client.upload_data(file_io, overwrite=True, metadata={"UploadedBy": user_oid})
    file_io.seek(0)
    ingester: UploadUserFileStrategy = current_app.config[CONFIG_INGESTER]
    await ingester.add_file(File(content=file_io, acls={"oids": [user_oid]}, url=file_client.url))
    return jsonify({"message": "File uploaded successfully"}), 200


@bp.post("/delete_uploaded")
@authenticated
async def delete_uploaded(auth_claims: dict[str, Any]):
    request_json = await request.get_json()
    filename = request_json.get("filename")
    user_oid = auth_claims["oid"]
    user_blob_container_client: FileSystemClient = current_app.config[CONFIG_USER_BLOB_CONTAINER_CLIENT]
    user_directory_client = user_blob_container_client.get_directory_client(user_oid)
    file_client = user_directory_client.get_file_client(filename)
    await file_client.delete_file()
    ingester = current_app.config[CONFIG_INGESTER]
    await ingester.remove_file(filename, user_oid)
    return jsonify({"message": f"File {filename} deleted successfully"}), 200


@bp.get("/list_uploaded")
@authenticated
async def list_uploaded(auth_claims: dict[str, Any]):
    user_oid = auth_claims["oid"]
    user_blob_container_client: FileSystemClient = current_app.config[CONFIG_USER_BLOB_CONTAINER_CLIENT]
    files = []
    try:
        all_paths = user_blob_container_client.get_paths(path=user_oid)
        async for path in all_paths:
            files.append(path.name.split("/", 1)[1])
    except ResourceNotFoundError as error:
        if error.status_code != 404:
            current_app.logger.exception("Error listing uploaded files", error)
    return jsonify(files), 200


# Chat.tsx, api.ts からコールされるインデックス名を取得するエンドポイント
@bp.route("/search_indexes", methods=["GET"])
async def get_search_indexes():
    try:
        search_index_client = SearchIndexClient(
            endpoint=f"https://{os.getenv('AZURE_SEARCH_SERVICE')}.search.windows.net",
            credential=AzureKeyCredential(os.getenv('AZURE_SEARCH_SERVICE_ADMIN_KEY'))
        )
        indexes_itempaged = search_index_client.list_index_names()
        # indexes_lst = [index async for index in indexes_itempaged if "gptkbindex" not in index and "-file" not in index]
        indexes_lst = [index async for index in indexes_itempaged if "index-" in index and "-file" not in index]
        return jsonify(indexes_lst)
    except Exception as e:
        return jsonify({"error": str(e)}), 500


async def create_index(index_name):
    
    fields = [
        SimpleField(name="id_question", type="Edm.String", key=True),
        SimpleField(name="question", type="Edm.String", filterable=True, facetable=True),
        SimpleField(name="answer", type="Edm.String", filterable=True, facetable=True),
        SimpleField(name="keyphrases", type="Edm.String", filterable=True, facetable=True),
        SimpleField(name="n_good", type="Edm.Int32", filterable=True, facetable=True),
        SimpleField(name="n_bad", type="Edm.Int32", filterable=True, facetable=True),
    ]
    
    try:
        search_index_client = SearchIndexClient(
            endpoint=f"https://{os.getenv('AZURE_SEARCH_SERVICE')}.search.windows.net",
            credential=AzureKeyCredential(os.getenv('AZURE_SEARCH_SERVICE_ADMIN_KEY'))
        )
        indexes_itempaged = search_index_client.list_index_names()
        indexes_lst = [index async for index in indexes_itempaged]
        if index_name not in indexes_lst:
            index = SearchIndex(
                name=index_name,
                fields=fields,
            )
            print(f"Creating {index_name} search index")
            result = await search_index_client.create_or_update_index(index)
            # print(f'{result.name} created')
        # else:
        #     print(f"Search index {index_name} already exists")
    except Exception as e:
        current_app.logger.exception(f"Error creating or updating index {index_name}", e)
    search_index_client = SearchIndexClient(
        endpoint=f"https://{os.getenv('AZURE_SEARCH_SERVICE')}.search.windows.net",
        credential=AzureKeyCredential(os.getenv('AZURE_SEARCH_SERVICE_ADMIN_KEY'))
    )
    indexes_itempaged = search_index_client.list_index_names()
    indexes_lst = [index async for index in indexes_itempaged]
    if index_name not in indexes_lst:
        index = SearchIndex(
            name=index_name,
            fields=fields,
        )
        print(f"Creating {index_name} search index")
        result = await search_index_client.create_or_update_index(index) 
        # print(f'{result.name} created')
    # else:
    #     print(f"Search index {index_name} already exists")


def question_to_id(question):
    question_ascii = re.sub("[^0-9a-zA-Z_-]", "_", question)
    question_hash = base64.b16encode(question.encode('utf-8')).decode('ascii')
    return f"question-{question_ascii}-{question_hash}"


# Goodボタン/Badボタンが押下された場合にコールされるエンドポイント
@bp.route("/feedback", methods=["POST"])
async def feedback():
    data = await request.get_json()
    feedback = data.get('feedback')
    history = data.get('history')
    
    # ユーザーが入力した質問文
    question_userinput = history[-1][0]
    
    # UI上で表示されている回答文 (キャッシュDBやFAQDBから参照された場合は上部に補足文が追記)
    answer_UIview = history[-1][1]['choices'][0]['message']['content']
    
    # 回答のメイン部分(補足文は削除済)
    # キャッシュDBやFAQDBに登録されている質問文
    answer_onlyMain, question_fmDB = await remove_answer_headmessage(answer_UIview)
    
    #######################################################
    # CasheDB の更新
    #######################################################
    index_name_casheDB = 'db-cashe'
    flag_record_exists = False
    
    # Create CasheDB Index (既存の場合はスキップ)
    await create_index(index_name_casheDB)
    
    #
    #  既存レコードのGood回数/Bad回数を更新 (Goodボタン/Badボタン押下時)
    #
    if MODE_RESPONSE == "CACHE_DB":
        search_client_casheDB = SearchClient(
            endpoint=f"https://{os.getenv('AZURE_SEARCH_SERVICE')}.search.windows.net",
            index_name=index_name_casheDB,
            credential=AzureKeyCredential(os.getenv('AZURE_SEARCH_SERVICE_ADMIN_KEY')),
        )
        search_filter_results = await search_client_casheDB.search(search_text="", filter=f"question eq '{question_fmDB}'")
        async for record in search_filter_results:
            flag_record_exists = True
            section = {
                "id_question": record["id_question"],
                "question": record["question"],
                "answer": record["answer"],
                "keyphrases": record["keyphrases"],
                "n_good": record["n_good"] + 1 if feedback == "good" else record["n_good"],
                "n_bad": record["n_bad"] + 1 if feedback == "bad" else record["n_bad"]
            }
            await search_client_casheDB.merge_documents(documents=[section])
    
    #
    # 新規レコードを追加 (Goodボタン押下時のみ)
    #
    if MODE_RESPONSE == "LLM":
        if feedback == "good" and not flag_record_exists:
            
            search_client_casheDB = SearchClient(
                endpoint=f"https://{os.getenv('AZURE_SEARCH_SERVICE')}.search.windows.net",
                index_name=index_name_casheDB,
                credential=AzureKeyCredential(os.getenv('AZURE_SEARCH_SERVICE_ADMIN_KEY')),
            )
            
            # 指示語を具体化した質問文
            question_userinput_replaced = await replace_ambiguous_terms(question_userinput, history)
            
            # キーフレーズを抽出
            keyphrases = await get_keyphrases(question_userinput_replaced)
            
            # レコード追加
            section = {
                "id_question": question_to_id(question_userinput_replaced),
                "question": question_userinput_replaced,
                "answer": answer_onlyMain,
                "keyphrases": keyphrases,
                "n_good": 1,
                "n_bad": 0,
            }
            results = await search_client_casheDB.upload_documents(documents=[section])
            # succeeded = sum([1 for r in results if r.succeeded])
            # print(f"\tIndexed {len(results)} sections, {succeeded} succeeded")
    
    #######################################################
    # FAQ候補リスト の更新
    #######################################################
    table_name_answer = "FAQCandidateList"
    
    #
    # 新規レコード追加 (Goodボタン/Badボタン押下時)
    #
    if MODE_RESPONSE in ["LLM", "CACHE_DB"]:
        
        connection_string = os.getenv("AZURE_STORAGE_CONNECTION_STRING")
        table_service_client = TableServiceClient.from_connection_string(conn_str=connection_string)
        
        # Create Table FAQ候補リスト (既存の場合はスキップ)
        table_client = await table_service_client.create_table_if_not_exists(table_name=table_name_answer)
        
        # 指示語を具体化した質問文
        question_userinput_replaced = await replace_ambiguous_terms(question_userinput, history)
        
        # レコード追加
        entity = {
            'PartitionKey': 'all',
            'RowKey': question_to_id(question_userinput_replaced),
            'Status': 0,
            'question': question_userinput_replaced,
            'answer': answer_onlyMain,
        }
        try:
            await table_client.create_entity(entity=entity)
        except ResourceExistsError:
            pass
    
    #######################################################
    # FAQDB の更新
    #######################################################
    index_name_FAQDB = 'db-faq'
    
    #
    #  既存レコードのGood回数/Bad回数を更新 (Goodボタン/Badボタン押下時)
    #
    if MODE_RESPONSE == "FAQ_DB":
    
        # インデックス一覧を取得
        search_index_client = SearchIndexClient(
            endpoint=f"https://{os.getenv('AZURE_SEARCH_SERVICE')}.search.windows.net",
            credential=AzureKeyCredential(os.getenv('AZURE_SEARCH_SERVICE_ADMIN_KEY')),
        )
        indexes_itempaged = search_index_client.list_index_names()
        indexes_lst = [index async for index in indexes_itempaged]
        
        if index_name_FAQDB in indexes_lst:
            search_client_FAQDB = SearchClient(
                endpoint=f"https://{os.getenv('AZURE_SEARCH_SERVICE')}.search.windows.net",
                index_name=index_name_FAQDB,
                credential=AzureKeyCredential(os.getenv('AZURE_SEARCH_SERVICE_ADMIN_KEY')),
            )
            search_filter_results = await search_client_FAQDB.search(search_text="", filter=f"question eq '{question_fmDB}'")
            async for record in search_filter_results:
                section = {
                    "RowKey": record["RowKey"],
                    "question": record["question"],
                    "answer": record["answer"],
                    "n_good": record["n_good"] + 1 if feedback == "good" else record["n_good"],
                    "n_bad": record["n_bad"] + 1 if feedback == "bad" else record["n_bad"],
                    "emb_question": record["emb_question"],
                }
                await search_client_FAQDB.merge_documents(documents=[section])
    
    
    #######################################################
    # Return (更新終了)
    #######################################################
    return jsonify({"status": "success"}), 200


@bp.before_app_serving
async def setup_clients():
    # Replace these with your own values, either in environment variables or directly here
    
    AZURE_STORAGE_ACCOUNT = os.environ["AZURE_STORAGE_ACCOUNT"]
    
    
    # AZURE_STORAGE_CONTAINER = os.environ["AZURE_STORAGE_CONTAINER"]
    AZURE_STORAGE_CONTAINER = os.environ["CONTAINER_NAME"]
    
    
    AZURE_USERSTORAGE_ACCOUNT = os.environ.get("AZURE_USERSTORAGE_ACCOUNT")
    AZURE_USERSTORAGE_CONTAINER = os.environ.get("AZURE_USERSTORAGE_CONTAINER")
    AZURE_SEARCH_SERVICE = os.environ["AZURE_SEARCH_SERVICE"]
    
    
    # AZURE_SEARCH_INDEX = os.environ["AZURE_SEARCH_INDEX"]
    AZURE_SEARCH_INDEX = os.environ["SEARCH_INDEX_CHUNKS_NAME"]
    AZURE_SEARCH_INDEX_FILE = f"{AZURE_SEARCH_INDEX}-file"
    
    
    AZURE_SEARCH_SECRET_NAME = os.getenv("AZURE_SEARCH_SECRET_NAME")
    AZURE_KEY_VAULT_NAME = os.getenv("AZURE_KEY_VAULT_NAME")
    # Shared by all OpenAI deployments
    OPENAI_HOST = os.getenv("OPENAI_HOST", "azure")
    OPENAI_CHATGPT_MODEL = os.environ["AZURE_OPENAI_CHATGPT_MODEL"]
    OPENAI_EMB_MODEL = os.getenv("AZURE_OPENAI_EMB_MODEL_NAME", "text-embedding-ada-002")
    OPENAI_EMB_DIMENSIONS = int(os.getenv("AZURE_OPENAI_EMB_DIMENSIONS", 1536))
    # Used with Azure OpenAI deployments
    AZURE_OPENAI_SERVICE = os.getenv("AZURE_OPENAI_SERVICE")
    AZURE_OPENAI_GPT4V_DEPLOYMENT = os.environ.get("AZURE_OPENAI_GPT4V_DEPLOYMENT")
    AZURE_OPENAI_GPT4V_MODEL = os.environ.get("AZURE_OPENAI_GPT4V_MODEL")
    AZURE_OPENAI_CHATGPT_DEPLOYMENT = (
        os.getenv("AZURE_OPENAI_CHATGPT_DEPLOYMENT") if OPENAI_HOST.startswith("azure") else None
    )
    AZURE_OPENAI_EMB_DEPLOYMENT = os.getenv("AZURE_OPENAI_EMB_DEPLOYMENT") if OPENAI_HOST.startswith("azure") else None
    AZURE_VISION_ENDPOINT = os.getenv("AZURE_VISION_ENDPOINT", "")
    # Used only with non-Azure OpenAI deployments
    OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
    OPENAI_ORGANIZATION = os.getenv("OPENAI_ORGANIZATION")

    AZURE_TENANT_ID = os.getenv("AZURE_TENANT_ID")
    AZURE_USE_AUTHENTICATION = os.getenv("AZURE_USE_AUTHENTICATION", "").lower() == "true"
    AZURE_ENFORCE_ACCESS_CONTROL = os.getenv("AZURE_ENFORCE_ACCESS_CONTROL", "").lower() == "true"
    AZURE_SERVER_APP_ID = os.getenv("AZURE_SERVER_APP_ID")
    AZURE_SERVER_APP_SECRET = os.getenv("AZURE_SERVER_APP_SECRET")
    AZURE_CLIENT_APP_ID = os.getenv("AZURE_CLIENT_APP_ID")
    AZURE_AUTH_TENANT_ID = os.getenv("AZURE_AUTH_TENANT_ID", AZURE_TENANT_ID)

    KB_FIELDS_CONTENT = os.getenv("KB_FIELDS_CONTENT", "content")
    KB_FIELDS_SOURCEPAGE = os.getenv("KB_FIELDS_SOURCEPAGE", "sourcepage")

    AZURE_SEARCH_QUERY_LANGUAGE = os.getenv("AZURE_SEARCH_QUERY_LANGUAGE", "en-us")
    AZURE_SEARCH_QUERY_SPELLER = os.getenv("AZURE_SEARCH_QUERY_SPELLER", "lexicon")
    AZURE_SEARCH_SEMANTIC_RANKER = os.getenv("AZURE_SEARCH_SEMANTIC_RANKER", "free").lower()

    USE_GPT4V = os.getenv("USE_GPT4V", "").lower() == "true"
    USE_USER_UPLOAD = os.getenv("USE_USER_UPLOAD", "").lower() == "true"

    # Use the current user identity to authenticate with Azure OpenAI, AI Search and Blob Storage (no secrets needed,
    # just use 'az login' locally, and managed identity when deployed on Azure). If you need to use keys, use separate AzureKeyCredential instances with the
    # keys for each service
    # If you encounter a blocking error during a DefaultAzureCredential resolution, you can exclude the problematic credential by using a parameter (ex. exclude_shared_token_cache_credential=True)
    azure_credential = DefaultAzureCredential(exclude_shared_token_cache_credential=True)

    # Fetch any necessary secrets from Key Vault
    search_key = None
    if AZURE_KEY_VAULT_NAME:
        async with SecretClient(
            vault_url=f"https://{AZURE_KEY_VAULT_NAME}.vault.azure.net", credential=azure_credential
        ) as key_vault_client:
            search_key = (
                AZURE_SEARCH_SECRET_NAME and (await key_vault_client.get_secret(AZURE_SEARCH_SECRET_NAME)).value  # type: ignore[attr-defined]
            )

    # Set up clients for AI Search and Storage
    search_credential: Union[AsyncTokenCredential, AzureKeyCredential] = (
        AzureKeyCredential(search_key) if search_key else azure_credential
    )
    search_client = SearchClient(
        endpoint=f"https://{AZURE_SEARCH_SERVICE}.search.windows.net",
        index_name=AZURE_SEARCH_INDEX,
        credential=search_credential,
    )
    
    search_client_file = SearchClient(
        endpoint=f"https://{AZURE_SEARCH_SERVICE}.search.windows.net",
        index_name=AZURE_SEARCH_INDEX_FILE,
        credential=search_credential,
    )
    

    blob_container_client = ContainerClient(
        f"https://{AZURE_STORAGE_ACCOUNT}.blob.core.windows.net", AZURE_STORAGE_CONTAINER, credential=azure_credential
    )

    # Set up authentication helper
    search_index = None
    if AZURE_USE_AUTHENTICATION:
        search_index_client = SearchIndexClient(
            endpoint=f"https://{AZURE_SEARCH_SERVICE}.search.windows.net",
            credential=search_credential,
        )
        search_index = await search_index_client.get_index(AZURE_SEARCH_INDEX)
        await search_index_client.close()
    auth_helper = AuthenticationHelper(
        search_index=search_index,
        use_authentication=AZURE_USE_AUTHENTICATION,
        server_app_id=AZURE_SERVER_APP_ID,
        server_app_secret=AZURE_SERVER_APP_SECRET,
        client_app_id=AZURE_CLIENT_APP_ID,
        tenant_id=AZURE_AUTH_TENANT_ID,
        require_access_control=AZURE_ENFORCE_ACCESS_CONTROL,
    )

    if USE_USER_UPLOAD:
        current_app.logger.info("USE_USER_UPLOAD is true, setting up user upload feature")
        if not AZURE_USERSTORAGE_ACCOUNT or not AZURE_USERSTORAGE_CONTAINER:
            raise ValueError(
                "AZURE_USERSTORAGE_ACCOUNT and AZURE_USERSTORAGE_CONTAINER must be set when USE_USER_UPLOAD is true"
            )
        user_blob_container_client = FileSystemClient(
            f"https://{AZURE_USERSTORAGE_ACCOUNT}.dfs.core.windows.net",
            AZURE_USERSTORAGE_CONTAINER,
            credential=azure_credential,
        )
        current_app.config[CONFIG_USER_BLOB_CONTAINER_CLIENT] = user_blob_container_client

        # Set up ingester
        file_processors = setup_file_processors(
            azure_credential=azure_credential,
            document_intelligence_service=os.getenv("AZURE_DOCUMENTINTELLIGENCE_SERVICE"),
            local_pdf_parser=os.getenv("USE_LOCAL_PDF_PARSER", "").lower() == "true",
            local_html_parser=os.getenv("USE_LOCAL_HTML_PARSER", "").lower() == "true",
            search_images=USE_GPT4V,
        )
        search_info = await setup_search_info(
            search_service=AZURE_SEARCH_SERVICE,
            index_name=AZURE_SEARCH_INDEX,
            azure_credential=azure_credential,
            search_key=clean_key_if_exists(search_key),
        )
        text_embeddings_service = setup_embeddings_service(
            azure_credential=azure_credential,
            openai_host=OPENAI_HOST,
            openai_model_name=OPENAI_EMB_MODEL,
            openai_service=AZURE_OPENAI_SERVICE,
            openai_deployment=AZURE_OPENAI_EMB_DEPLOYMENT,
            openai_dimensions=OPENAI_EMB_DIMENSIONS,
            openai_key=clean_key_if_exists(OPENAI_API_KEY),
            openai_org=OPENAI_ORGANIZATION,
            disable_vectors=os.getenv("USE_VECTORS", "").lower() == "false",
        )
        ingester = UploadUserFileStrategy(
            search_info=search_info, embeddings=text_embeddings_service, file_processors=file_processors
        )
        current_app.config[CONFIG_INGESTER] = ingester

    # Used by the OpenAI SDK
    openai_client: AsyncOpenAI

    if OPENAI_HOST.startswith("azure"):
        token_provider = get_bearer_token_provider(azure_credential, "https://cognitiveservices.azure.com/.default")

        if OPENAI_HOST == "azure_custom":
            endpoint = os.environ["AZURE_OPENAI_CUSTOM_URL"]
        else:
            endpoint = f"https://{AZURE_OPENAI_SERVICE}.openai.azure.com"

        api_version = os.getenv("AZURE_OPENAI_API_VERSION") or "2024-03-01-preview"

        openai_client = AsyncAzureOpenAI(
            api_version=api_version,
            azure_endpoint=endpoint,
            azure_ad_token_provider=token_provider,
        )
    elif OPENAI_HOST == "local":
        openai_client = AsyncOpenAI(
            base_url=os.environ["OPENAI_BASE_URL"],
            api_key="no-key-required",
        )
    else:
        openai_client = AsyncOpenAI(
            api_key=OPENAI_API_KEY,
            organization=OPENAI_ORGANIZATION,
        )

    current_app.config[CONFIG_OPENAI_CLIENT] = openai_client
    current_app.config[CONFIG_SEARCH_CLIENT] = search_client
    current_app.config[CONFIG_BLOB_CONTAINER_CLIENT] = blob_container_client
    current_app.config[CONFIG_AUTH_CLIENT] = auth_helper

    current_app.config[CONFIG_GPT4V_DEPLOYED] = bool(USE_GPT4V)
    current_app.config[CONFIG_SEMANTIC_RANKER_DEPLOYED] = AZURE_SEARCH_SEMANTIC_RANKER != "disabled"
    current_app.config[CONFIG_VECTOR_SEARCH_ENABLED] = os.getenv("USE_VECTORS", "").lower() != "false"
    current_app.config[CONFIG_USER_UPLOAD_ENABLED] = bool(USE_USER_UPLOAD)

    current_app.config[CONFIG_CHAT_APPROACH] = ChatReadRetrieveReadApproach(
        search_client=search_client,
        search_client_file=search_client_file, 
        openai_client=openai_client,
        auth_helper=auth_helper,
        chatgpt_model=OPENAI_CHATGPT_MODEL,
        chatgpt_deployment=AZURE_OPENAI_CHATGPT_DEPLOYMENT,
        embedding_model=OPENAI_EMB_MODEL,
        embedding_deployment=AZURE_OPENAI_EMB_DEPLOYMENT,
        embedding_dimensions=OPENAI_EMB_DIMENSIONS,
        sourcepage_field=KB_FIELDS_SOURCEPAGE,
        content_field=KB_FIELDS_CONTENT,
        query_language=AZURE_SEARCH_QUERY_LANGUAGE,
        query_speller=AZURE_SEARCH_QUERY_SPELLER,
    )


@bp.after_app_serving
async def close_clients():
    await current_app.config[CONFIG_SEARCH_CLIENT].close()
    await current_app.config[CONFIG_BLOB_CONTAINER_CLIENT].close()
    if current_app.config.get(CONFIG_USER_BLOB_CONTAINER_CLIENT):
        await current_app.config[CONFIG_USER_BLOB_CONTAINER_CLIENT].close()


def create_app():
    app = Quart(__name__)
    app.register_blueprint(bp)

    if os.getenv("APPLICATIONINSIGHTS_CONNECTION_STRING"):
        configure_azure_monitor()
        # This tracks HTTP requests made by aiohttp:
        AioHttpClientInstrumentor().instrument()
        # This tracks HTTP requests made by httpx:
        HTTPXClientInstrumentor().instrument()
        # This tracks OpenAI SDK requests:
        OpenAIInstrumentor().instrument()
        # This middleware tracks app route requests:
        app.asgi_app = OpenTelemetryMiddleware(app.asgi_app)  # type: ignore[assignment]

    # Level should be one of https://docs.python.org/3/library/logging.html#logging-levels
    default_level = "INFO"  # In development, log more verbosely
    if os.getenv("WEBSITE_HOSTNAME"):  # In production, don't log as heavily
        default_level = "WARNING"
    logging.basicConfig(level=os.getenv("APP_LOG_LEVEL", default_level))

    if allowed_origin := os.getenv("ALLOWED_ORIGIN"):
        app.logger.info("CORS enabled for %s", allowed_origin)
        cors(app, allow_origin=allowed_origin, allow_methods=["GET", "POST"])
    return app
