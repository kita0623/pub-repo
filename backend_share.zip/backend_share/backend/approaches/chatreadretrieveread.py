from typing import Any, Coroutine, List, Literal, Optional, Union, overload

from azure.search.documents.aio import SearchClient
from azure.search.documents.models import VectorQuery
from openai import AsyncOpenAI, AsyncStream
from openai.types.chat import (
    ChatCompletion,
    ChatCompletionChunk,
    ChatCompletionToolParam,
)

from approaches.approach import ThoughtStep
from approaches.chatapproach import ChatApproach
from core.authentication import AuthenticationHelper
from core.modelhelper import get_token_limit

import asyncio
import openai
import os
import time
import pandas as pd
from io import StringIO

from azure.core.credentials import AzureKeyCredential
from azure.search.documents.indexes import SearchIndexClient

def elapsed_time(t):
    elapsed_time = int(time.time() - t)
    elapsed_hour = elapsed_time // 3600
    elapsed_minute = (elapsed_time % 3600) // 60
    elapsed_second = (elapsed_time % 3600 % 60)
    return str(elapsed_hour).zfill(2) + ":" + str(elapsed_minute).zfill(2) + ":" + str(elapsed_second).zfill(2)


class ChatReadRetrieveReadApproach(ChatApproach):
    """
    A multi-step approach that first uses OpenAI to turn the user's question into a search query,
    then uses Azure AI Search to retrieve relevant documents, and then sends the conversation history,
    original user question, and search results_search to OpenAI to generate a response.
    """

    def __init__(
        self,
        *,
        search_client: SearchClient,
        search_client_file: SearchClient,
        auth_helper: AuthenticationHelper,
        openai_client: AsyncOpenAI,
        chatgpt_model: str,
        chatgpt_deployment: Optional[str],  # Not needed for non-Azure OpenAI
        embedding_deployment: Optional[str],  # Not needed for non-Azure OpenAI or for retrieval_mode="text"
        embedding_model: str,
        embedding_dimensions: int,
        sourcepage_field: str,
        content_field: str,
        query_language: str,
        query_speller: str,
    ):
        self.search_client = search_client
        self.search_client_file = search_client_file
        self.openai_client = openai_client
        self.auth_helper = auth_helper
        self.chatgpt_model = chatgpt_model
        self.chatgpt_deployment = chatgpt_deployment
        self.embedding_deployment = embedding_deployment
        self.embedding_model = embedding_model
        self.embedding_dimensions = embedding_dimensions
        self.sourcepage_field = sourcepage_field
        self.content_field = content_field
        self.query_language = query_language
        self.query_speller = query_speller
        self.chatgpt_token_limit = get_token_limit(chatgpt_model)
        
        self.setting_model = {
            # Azure OpenAI
            "gpt-4-turbo-2024-04-09 (Azure OpenAI)": {
                "client_type": "azure_openai",
                "deployment": f"{os.getenv('AZURE_OPENAI_GPT4_TURBO_20240409_DEPLOYMENT')}",
                "token_limit": 128000,
            },
            "gpt-4-1106-preview (Azure OpenAI)": {
                "client_type": "azure_openai",
                "deployment": f"{os.getenv('AZURE_OPENAI_GPT4_1106_PREVIEW_DEPLOYMENT')}",
                "token_limit": 128000,
            },
            "gpt-4-vision-preview (Azure OpenAI)": {
                "client_type": "azure_openai",
                "deployment": f"{os.getenv('AZURE_OPENAI_GPT4V_DEPLOYMENT')}",
                "token_limit": 128000,
            },
            "gpt-4-32k (Azure OpenAI)": {
                "client_type": "azure_openai",
                "deployment": f"{os.getenv('AZURE_OPENAI_GPT4_32K_DEPLOYMENT')}",
                "token_limit": 32000,
            },
            "gpt-4 (Azure OpenAI)": {
                "client_type": "azure_openai",
                "deployment": f"{os.getenv('AZURE_OPENAI_GPT4_DEPLOYMENT')}",
                "token_limit": 8100,
            },
            "gpt-3.5-turbo-0613 (Azure OpenAI)": {
                "client_type": "azure_openai",
                "deployment": f"{os.getenv('AZURE_OPENAI_GPT35_TURBO_DEPLOYMENT')}",
                "token_limit": 4000,
            },
            
            # OpenAI
            "gpt-4o (OpenAI)": {
                "client_type": "openai",
                "deployment": "gpt-4o",
                "token_limit": 128000,
            },
            "gpt-4-turbo-2024-04-09 (OpenAI)": {
                "client_type": "openai",
                "deployment": "gpt-4-turbo-2024-04-09",
                "token_limit": 128000,
            },
            "gpt-4-1106-preview (OpenAI)": {
                "client_type": "openai",
                "deployment": "gpt-4-1106-preview",
                "token_limit": 128000,
            },
            "gpt-4-vision-preview (OpenAI)": {
                "client_type": "openai",
                "deployment": "gpt-4-vision-preview",
                "token_limit": 128000,
            },
            "gpt-4-32k (OpenAI)": {
                "client_type": "openai",
                "deployment": "gpt-4-32k",
                "token_limit": 32000,
            },
            "gpt-3.5-turbo-0125 (OpenAI)": {
                "client_type": "openai",
                "deployment": "gpt-3.5-turbo-0125",
                "token_limit": 16000,
            },
            "gpt-3.5-turbo-0613 (OpenAI)": {
                "client_type": "openai",
                "deployment": "gpt-3.5-turbo-0613",
                "token_limit": 4000,
            },
        }

    # @property
    # def system_message_chat_conversation(self):
    #     return """Assistant helps the company employees with their healthcare plan questions, and questions about the employee handbook. Be brief in your answers.
    #     Answer ONLY with the facts listed in the list of sources below. If there isn't enough information below, say you don't know. Do not generate answers that don't use the sources below. If asking a clarifying question to the user would help, ask the question.
    #     For tabular information return it as an html table. Do not return markdown format. If the question is not in English, answer in the language used in the question.
    #     Each source has a name followed by colon and the actual information, always include the source name for each fact you use in the response. Use square brackets to reference the source, for example [info1.txt]. Don't combine sources, list each source separately, for example [info1.txt][info2.pdf].
    #     {follow_up_questions_prompt}
    #     {injected_prompt}
    #     """
    
    @property
    def system_message_chat_conversation(self):
        return """アシスタントは、ユーザーの質問に対して支援します。回答は簡潔にしてください。
        以下の情報源リスト"Sources"や入力画像に記載されている事実のみを用いて回答してください。情報が不足している場合は、「わからない」と回答してください。以下の情報源リストを使用しない回答は生成しないでください。ユーザーに明確化の質問をすることが役立つ場合は、質問をしてください。
        表形式の情報はHTMLテーブルとして返してください。Markdown形式で返さないでください。必ず日本語で回答してください。
        各情報源"Sources"には名前があり、その後に実際の情報が続きます。回答に使用する各事実について、常に情報源の名前を含めてください。情報源を参照するには角括弧を使用してください。例：[info1.pdf#gage=3]。情報源を組み合わせずに、各情報源を個別にリストしてください。例：[info1.pdf#gage=3][info2.pdf#gage=4]。
        入力画像の中に記載されているOCRテキストを抽出して以下の"OCR text of images"に記載しています。回答生成に入力画像を使用する際はOCRテキストを参考にしてください。ただし、OCRにより画像内のテキストが読み取られる際に、元の文の構造や単語の並びが正しくない場合があるため、OCRテキストをそのまま信頼せず、画像から得られる視覚的な情報を重視してください。
        入力画像の入力順序とOCRテキストの記載順序は一致します。
        {follow_up_questions_prompt}
        {injected_prompt}
        """
    
    @property
    def system_message_chat_conversation_subquery(self):
        return """アシスタントは、ユーザーの質問に対して支援します。回答は簡潔にしてください。
        以下の情報源リスト"Sources"に記載されている事実のみを用いて回答してください。情報が不足している場合は、「わからない」と回答してください。以下の情報源リストを使用しない回答は生成しないでください。ユーザーに明確化の質問をすることが役立つ場合は、質問をしてください。
        表形式の情報はHTMLテーブルとして返してください。Markdown形式で返さないでください。必ず日本語で回答してください。
        各情報源"Sources"には複数のサブ質問とサブ回答と対応する情報源が記載されています。回答に使用する各事実について、常に情報源の名前を含めてください。情報源を参照するには角括弧を使用してください。例：[info1.pdf#gage=3]。情報源を組み合わせずに、各情報源を個別にリストしてください。例：[info1.pdf#gage=3][info2.pdf#gage=4]。
        {follow_up_questions_prompt}
        {injected_prompt}
        """

    @overload
    async def run_until_final_call(
        self,
        history: list[dict[str, str]],
        overrides: dict[str, Any],
        auth_claims: dict[str, Any],
        should_stream: Literal[False],
    ) -> tuple[dict[str, Any], Coroutine[Any, Any, ChatCompletion]]: ...

    @overload
    async def run_until_final_call(
        self,
        history: list[dict[str, str]],
        overrides: dict[str, Any],
        auth_claims: dict[str, Any],
        should_stream: Literal[True],
    ) -> tuple[dict[str, Any], Coroutine[Any, Any, AsyncStream[ChatCompletionChunk]]]: ...

    async def run_until_final_call(
        self,
        history: list[dict[str, str]],
        overrides: dict[str, Any],
        auth_claims: dict[str, Any],
        should_stream: bool = False,
    ) -> tuple[dict[str, Any], Coroutine[Any, Any, Union[ChatCompletion, AsyncStream[ChatCompletionChunk]]]]:
        start_time = time.time()
        has_text = overrides.get("retrieval_mode") in ["text", "hybrid", None]
        has_vector = overrides.get("retrieval_mode") in ["vectors", "hybrid", None]
        use_semantic_captions = True if overrides.get("semantic_captions") and has_text else False
        top = overrides.get("top", 3)
        minimum_search_score = overrides.get("minimum_search_score", 0.0)
        minimum_reranker_score = overrides.get("minimum_reranker_score", 0.0)

        filter = self.build_filter(overrides, auth_claims)
        use_semantic_ranker = True if overrides.get("semantic_ranker") and has_text else False

        flag_multimodal_search = overrides.get("multimodal_search", False) # マルチモーダル検索
        flag_two_step_search = overrides.get("two_step_search", False) # 二段階検索
        flag_sub_query = overrides.get("sub_query", False) # サブクエリ
        
        original_user_query = history[-1]["content"]
        # user_query_request = "Generate search query for: " + original_user_query
        user_query_request = "検索クエリを生成してください: " + original_user_query

        tools: List[ChatCompletionToolParam] = [
            {
                "type": "function",
                "function": {
                    "name": "search_sources",
                    "description": "Retrieve sources from the Azure AI Search index",
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "search_query": {
                                "type": "string",
                                "description": "Query string to retrieve documents from azure search eg: 'Health care plan'",
                            }
                        },
                        "required": ["search_query"],
                    },
                },
            }
        ]
        
        
        async def create_multi_vectors(query_text, ref_index):
            """
            マルチベクトル検索のためのマルチベクトルクエリ作成
            """

            credential = AzureKeyCredential(os.getenv("AZURE_SEARCH_SERVICE_ADMIN_KEY"))
            search_index_client = SearchIndexClient(
                endpoint=f"https://{os.getenv('AZURE_SEARCH_SERVICE')}.search.windows.net", 
                credential=credential
            )
            
            index = search_index_client.get_index(ref_index)
            dic_vectorfields_dimention = {field.name: field.vector_search_dimensions for field in index.fields if field.vector_search_dimensions is not None}
            
            vectors = []
            if has_vector:
                for field, dimention in dic_vectorfields_dimention.items():
                    vector = (
                        await self.compute_text_embedding_aivision(query_text, field) # Azure AI Vision Embedding (1024次元)
                        if dimention == 1024
                        else await self.compute_text_embedding(query_text, field) # OpenAI Embedding (1536次元)
                        if dimention == 1536
                        else None
                    )
                    vectors.append(vector)
                    if vector is None:
                        raise ValueError(f"Unsupported embedding dimension: {dimention}")
            return vectors


        #######################################################################################################################
        # STEP 1: Generate an optimized keyword search query based on the chat history and the last question
        #######################################################################################################################
        
        #-------------------------------------------------------------------
        # 検索クエリ生成
        #-------------------------------------------------------------------
        
        if not flag_sub_query or flag_two_step_search:
            
            # モデル選択
            model_selected = overrides.get("create_query_gpt_input", "gpt-4-turbo-2024-04-09 (Azure OpenAI)")
            client_type = self.setting_model[model_selected]["client_type"]
            if client_type not in ["azure_openai", "openai"]:
                raise ValueError(f"Invalid model selected: {model_selected}")
            
            messages_for_creating_query = self.get_messages_from_history(
                system_prompt=self.query_prompt_template,
                model_id=self.chatgpt_model, # tiktokenの登録名を使用し、../core/modelhelper.py の AOAI_2_OAI 等と整合性が合っている必要があるため、正確なmodel_idの反映は劣後
                history=history,
                user_content=user_query_request,
                max_tokens=self.setting_model[model_selected]["token_limit"] - len(user_query_request), # self.chatgpt_token_limit - len(user_query_request)
                # few_shots=self.query_prompt_few_shots,
            )

            client = self.openai_client if client_type == "azure_openai" else openai.AsyncOpenAI(api_key=os.environ["OPENAI_API_KEY"])
            chat_completion: ChatCompletion = await client.chat.completions.create(
                messages=messages_for_creating_query,
                model=self.setting_model[model_selected]["deployment"],
                temperature=0.0,  # Minimize creativity for search query generation
                max_tokens=500,   # 100, # Setting too low risks malformed JSON, setting too high may affect performance
                n=1,
                tools=tools,
                tool_choice="auto",
            )

            query_text = self.get_search_query(chat_completion, original_user_query)
        
        
        #-------------------------------------------------------------------
        # サブクエリ作成
        #-------------------------------------------------------------------
        
        if flag_sub_query:
            
            n_try = 0
            while True:
            
                # モデル選択
                model_selected = overrides.get("create_sub_query_gpt_input", "gpt-4-turbo-2024-04-09 (Azure OpenAI)")
                client_type = self.setting_model[model_selected]["client_type"]
                if client_type not in ["azure_openai", "openai"]:
                    raise ValueError(f"Invalid model selected: {model_selected}")
                
                system_prompt_added_for_subquery = """
                ユーザーの質問が複雑な場合は、複数のサブ質問に分割して、複数の検索クエリを生成してください。
                回答はカンマ区切りで返してください。
                
                ### ユーザーの質問例 ###
                MicrosoftとGoogleの2023年四半期決算の売上高と純利益は？
                
                ### 回答例 ###
                "Microsoftの2023年の四半期決算に関して売上高は？","Googleの2023年の四半期決算に関して売上高は？","Microsoftの2023年の四半期決算に関して純利益は？","Googleの2023年の四半期決算に関して純利益は？"
                """
                
                messages_for_creating_subquery = self.get_messages_from_history(
                    system_prompt=self.query_prompt_template + system_prompt_added_for_subquery,
                    model_id=self.chatgpt_model, # 既出理由により劣後
                    history=history,
                    user_content=user_query_request,
                    max_tokens=self.setting_model[model_selected]["token_limit"] - len(user_query_request), # self.chatgpt_token_limit - len(user_query_request)
                    # few_shots=self.query_prompt_few_shots,
                )

                client = self.openai_client if client_type == "azure_openai" else openai.AsyncOpenAI(api_key=os.environ["OPENAI_API_KEY"])
                chat_completion: ChatCompletion = await client.chat.completions.create(
                    messages=messages_for_creating_subquery,
                    model=self.setting_model[model_selected]["deployment"],
                    temperature=0.0,  # Minimize creativity for search query generation
                    max_tokens=500,   # 100,   # Setting too low risks malformed JSON, setting too high may affect performance
                    n=1,
                    tools=tools,
                    tool_choice="auto",
                )
                
                response_content = chat_completion.choices[0].message.content
                if response_content:
                    lst_subquery_text = [item.strip('"').strip() for item in response_content.split(',')]
                    break
                else:
                    n_try += 1
                    if n_try > 3:
                        raise ValueError("Failed to generate subquery text after 3 tries")
                    else:
                        continue
        

        #######################################################################################################################
        # STEP 2: Retrieve relevant documents from the search index with the GPT optimized query
        #######################################################################################################################
        
        #-------------------------------------------------------------------
        # ファイル検索 (二段階検索)
        #-------------------------------------------------------------------
        
        if flag_two_step_search:
            
            # マルチベクトル
            vectors = await create_multi_vectors(query_text, ref_index="index-all-file")

            if not has_text:
                query_text = None

            results_file_search = await self.search(
                overrides.get("top_files", 1), # ファイル取得数
                query_text,
                filter,
                vectors,
                use_semantic_ranker,
                use_semantic_captions,
                minimum_search_score,
                minimum_reranker_score,
                mode="file_search"
            )
            
            filekey_file_search = [result.filekey for result in results_file_search]


        #-------------------------------------------------------------------
        # チャンク検索
        #-------------------------------------------------------------------
        
        # フィルター(二段階検索時)
        if flag_two_step_search:
            filekey_str = ','.join(f"{filekey}" for filekey in filekey_file_search)
            filter = f"search.in(filekey, '{filekey_str}', ',')"
        
        # フィルター(マルチモーダル使用時)
        if not flag_multimodal_search:
            filter_no_img = "category ne 'img-type'"
            if filter:
                filter += " and " + filter_no_img
            else:
                filter = filter_no_img
        
        # 検索
        if not flag_sub_query:
            
            if not has_text:
                query_text = None
            
            # マルチベクトル
            vectors = await create_multi_vectors(query_text, ref_index="index-all")
        
            results_search = await self.search(
                top,
                query_text,
                filter,
                vectors,
                use_semantic_ranker,
                use_semantic_captions,
                minimum_search_score,
                minimum_reranker_score,
            )
        
        # 検索(サブクエリ使用時) 
        else:
            results_search_subquery = {}
            for subquery_text in lst_subquery_text:
                
                if not has_text:
                    subquery_text = None
                
                # マルチベクトル
                vectors = await create_multi_vectors(subquery_text, ref_index="index-all")
                
                results_search = await self.search(
                    overrides.get("top_sub_query", 1), # サブクエリ毎のチャンク取得数
                    subquery_text,
                    filter,
                    vectors,
                    use_semantic_ranker,
                    use_semantic_captions,
                    minimum_search_score,
                    minimum_reranker_score,
                )
                results_search_subquery[subquery_text] = results_search
                
            # result.idが重複しているものは片方を削除して重複がないようにする
            results_search = list({result.id: result for subquery in results_search_subquery.values() for result in subquery}.values())
        
        
        # sources_content = self.get_sources_content(results_search, use_semantic_captions, use_image_citation=False)
        # content = "\n".join(sources_content)
        
        def process_search_results(results_search):
            
            # Result をテキストソースと画像ソースに分ける
            results_only_text = [result for result in results_search if result.category != "img-type"]
            results_only_img = [result for result in results_search if result.category == "img-type"]
            
            # PPTタイプでテキストソースと画像ソースが重複する場合は、テキストソース側を削除する（画像ソース側でOCRテキストを組み込むため）
            lst_sourcepages_img = [result_img.sourcepage for result_img in results_only_img]
            results_only_text = [result_txt for result_txt in results_only_text if not (result_txt.category == "ppt-type" and result_txt.sourcepage in lst_sourcepages_img)]
            
            # テキストソース
            sources_content_text = self.get_sources_content(results_only_text, use_semantic_captions, use_image_citation=False)
            content_text = "\n".join(sources_content_text)
            
            # 画像ソース
            sources_content_img = self.get_sources_content(results_only_img, use_semantic_captions, use_image_citation=False) # OCRテキスト抽出
            content_img = "\n".join(sources_content_img)
            sources_summary_img = self.get_sources_summary(results_only_img, use_semantic_captions, use_image_citation=False) # 画像の要約文
            
            # 再結合 (表示用)
            sources_content = sources_content_text + sources_summary_img
            
            return results_only_text, results_only_img, content_text, content_img, sources_content
        
        
        #######################################################################################################################
        # STEP 2.5: プロンプト構成要素の作成
        #######################################################################################################################
        
        #
        # 独自用語とその説明
        #
        use_internal_terms = overrides.get("internal_terms", False)
        if use_internal_terms:
            lst_df_terms = []
            for result in results_search:
                data_io = StringIO(result.internalterms)
                df_terms = pd.read_csv(data_io, header=None, names=['略語', '正式名称', '説明'])
                lst_df_terms.append(df_terms)
            df_terms = pd.concat(lst_df_terms, ignore_index=True)
            df_terms = df_terms.drop_duplicates(subset=['略語'])
            if not df_terms.empty:
                terms_str = df_terms.to_csv(index=False, header=False, lineterminator='\n')
                user_content += "\n\nInternal terms:\n" + terms_str
        
        #
        # サブクエリ毎のサブアンサー
        #
        if flag_sub_query:
            
            lst_subquery_answer_sources = []
            messages_for_creating_subanswer_display = []
            tasks = []
            dic_subquery_text_to_allsources_str = {}

            for subquery_text, lst_result in results_search_subquery.items():
                
                # サブクエリ用のSearch結果
                results_only_text_subquery, results_only_img_subquery, content_text_subquery, content_img_subquery, _ = process_search_results(lst_result)
                textsources_sourcepage = [result.sourcepage for result in results_only_text_subquery]
                imagesources_sourcepage = [result.sourcepage for result in results_only_img_subquery]
                allsources_sourcepage = textsources_sourcepage + imagesources_sourcepage
                allsources_str = ", ".join(allsources_sourcepage)
                dic_subquery_text_to_allsources_str[subquery_text] = allsources_str
                
                # user_content
                user_content = subquery_text
                user_content += "\n\nSources:\n" + content_text_subquery if content_text_subquery else ""
                user_content += "\n\nOCR text of images:\n" + content_img_subquery if content_img_subquery else ""
                
                # messages_for_creating_subanswer
                messages_for_creating_subanswer = [{"role": "user", "content": user_content}]
                
                # messages_for_creating_subanswer を Vision対応GPT の形式に変更
                messages_for_creating_subanswer[-1]["content"] = [{"type": "text", "text": messages_for_creating_subanswer[-1]["content"]}]
                
                # messages_for_creating_subanswer_display (extra_info 表示用)
                messages_for_creating_subanswer_display.append(messages_for_creating_subanswer)
                
                # 画像データを messages_for_creating_subanswer に入れる
                imagefiles_lst = [result.sourcefile for result in results_only_img_subquery]
                lst_base64_image = await asyncio.gather(
                    *[self.load_image_from_blob_container_byImageFileName(imagefile_name) for imagefile_name in imagefiles_lst]
                )
                messages_for_creating_subanswer[-1]["content"] += [{"type": "image_url", "image_url": {"url": f"data:image/jpeg;base64,{base64_image}"}} for base64_image in lst_base64_image]
            
                # モデル選択
                model_selected = overrides.get("sub_answer_gpt_vision_input", "gpt-4o (OpenAI)")
                client_type = self.setting_model[model_selected]["client_type"]
                if client_type not in ["azure_openai", "openai"]:
                    raise ValueError(f"Invalid model selected: {model_selected}")

                client = self.openai_client if client_type == "azure_openai" else openai.AsyncOpenAI(api_key=os.environ["OPENAI_API_KEY"])
                
                task = client.chat.completions.create(
                    model=self.setting_model[model_selected]["deployment"],
                    messages=messages_for_creating_subanswer,
                    temperature=overrides.get("temperature", 0.3),
                    max_tokens=2000,
                    n=1,
                )
                tasks.append(task)

            results = await asyncio.gather(*tasks)

            for result, (subquery_text, _) in zip(results, results_search_subquery.items()):
                response_content = result.choices[0].message.content
                lst_subquery_answer_sources.append(f"{subquery_text}: {response_content} ({dic_subquery_text_to_allsources_str[subquery_text]})")


        #######################################################################################################################
        # STEP 3: Generate a contextual and content specific answer using the search results_search and chat history
        #######################################################################################################################
        
        # グローバル用のSearch結果
        _, results_only_img, content_text, content_img, sources_content = process_search_results(results_search)
        
        # モデル選択
        model_selected = overrides.get("answer_gpt_vision_input", "gpt-4-turbo-2024-04-09 (Azure OpenAI)")
        

        #
        # システムプロンプト
        #
        system_message = self.get_system_prompt(
            overrides.get("prompt_template"),
            self.follow_up_questions_prompt_content if overrides.get("suggest_followup_questions") else "",
            flag_sub_query,
        )
        
        
        #
        # user_content
        #

        # ユーザーの質問文
        user_content = original_user_query
        
        # ドキュメントソース と 画像OCRテキスト
        if not flag_sub_query:
            user_content += "\n\nSources:\n" + content_text if content_text else ""
            user_content += "\n\nOCR text of images:\n" + content_img if content_img else ""
        else:
            # Sources: としてサブクエリ,サブアンサー,ソースを追加
            user_content += "\n\nSources:\n" + "\n".join(lst_subquery_answer_sources) if lst_subquery_answer_sources else ""
        
        # 独自用語とその説明 を追加
        if use_internal_terms and not df_terms.empty:
            user_content += "\n\nInternal terms:\n" + terms_str

        #
        # messages_for_creating_answer (入力メッセージ)
        #
        response_token_limit = 1024
        messages_token_limit = self.setting_model[model_selected]["token_limit"] - response_token_limit, # self.chatgpt_token_limit - response_token_limit
        messages_for_creating_answer = self.get_messages_from_history(
            system_prompt=system_message,
            model_id=self.chatgpt_model, # 既出理由により劣後
            history=history,
            # Model does not handle lengthy system messages well. Moving sources to latest user conversation to solve follow up questions prompt.
            user_content=user_content, # original_user_query + "\n\nSources:\n" + content,
            max_tokens=messages_token_limit,
        )
        
        # messages_for_creating_answer を Vision対応GPT の形式に変更
        messages_for_creating_answer[-1]["content"] = [{"type": "text", "text": messages_for_creating_answer[-1]["content"]}]
        
        # messages_for_creating_answer_display (extra_info 表示用)
        messages_for_creating_answer_display = messages_for_creating_answer.copy()

        # 画像データを messages_for_creating_answer に入れる
        if not flag_sub_query:
            # 画像ファイルリストを取得
            imagefiles_lst = [result.sourcefile for result in results_only_img]
            # 画像ファイル名のリストから非同期に画像をロードし、そのbase64エンコードされたリストを取得
            lst_base64_image = await asyncio.gather(
                *[self.load_image_from_blob_container_byImageFileName(imagefile_name) for imagefile_name in imagefiles_lst]
            )
            # 画像データを messages_for_creating_answer に入れる
            messages_for_creating_answer[-1]["content"] += [{"type": "image_url", "image_url": {"url": f"data:image/jpeg;base64,{base64_image}"}} for base64_image in lst_base64_image]
        
        
        #
        # chat_coroutine
        #
        client_type = self.setting_model[model_selected]["client_type"]
        if client_type not in ["azure_openai", "openai"]:
            raise ValueError(f"Invalid model selected: {model_selected}")
        client = self.openai_client if client_type == "azure_openai" else openai.AsyncOpenAI(api_key=os.environ["OPENAI_API_KEY"])
        
        chat_coroutine = client.chat.completions.create(
            model=self.setting_model[model_selected]["deployment"],
            messages=messages_for_creating_answer,
            temperature=overrides.get("temperature", 0.3),
            max_tokens=response_token_limit,
            n=1,
            stream=should_stream,
        )
        
        
        #
        # extra_info
        #
        thoughts = []
        
        if flag_two_step_search:
            # 二段階検索/ファイル検索
            thoughts.append(ThoughtStep(
                "検索クエリ生成プロンプト(二段階検索/ファイル検索)",
                [str(message) for message in messages_for_creating_query],
                {
                    "GPT": overrides.get("create_query_gpt_input")
                }
            ))
            thoughts.append(ThoughtStep(
                "生成された検索クエリ(二段階検索/ファイル検索)",
                query_text, 
                None
            ))
            thoughts.append(ThoughtStep(
                "検索条件(二段階検索/ファイル検索)",
                None,
                {
                    "二段階検索のファイル取得数": overrides.get("top_files"),
                    "セマンティックランカー": use_semantic_ranker,
                    "セマンティックキャプション": use_semantic_captions,
                },
            ))
            thoughts.append(ThoughtStep(
                "検索結果(二段階検索/ファイル検索)",
                [result.serialize_for_results() for result in results_file_search],
                None
            ))

        # サブクエリのみ
        if flag_sub_query:
            thoughts.append(ThoughtStep(
                "サブクエリ生成プロンプト",
                [str(message) for message in messages_for_creating_subquery],
                {
                    "GPT": overrides.get("create_sub_query_gpt_input"),
                }
            ))
            thoughts.append(ThoughtStep(
                "生成されたサブクエリ",
                lst_subquery_text, 
                {
                    "生成されたサブクエリ数": len(lst_subquery_text),
                },
            ))
            thoughts.append(ThoughtStep(
                "検索条件(サブクエリ毎の検索)",
                None,
                {
                    "サブクエリ毎のチャンク取得数": overrides.get("top_sub_query"),
                    "セマンティックランカー": use_semantic_ranker,
                    "セマンティックキャプション": use_semantic_captions,
                },
            ))
            thoughts.append(ThoughtStep(
                "サブアンサー生成のプロンプト",
                [str(message) for message in messages_for_creating_subanswer_display],
                {
                    "GPT": overrides.get("answer_gpt_vision_input"),
                }
            ))
            thoughts.append(ThoughtStep(
                "サブクエリ/サブアンサー/引用",
                lst_subquery_answer_sources,
                None
            )) 
        
        # サブクエリ以外
        else: 
            thoughts.append(ThoughtStep(
                "検索クエリ生成プロンプト",
                [str(message) for message in messages_for_creating_query],
                {
                    "GPT": overrides.get("create_query_gpt_input")
                }
            ))
            thoughts.append(ThoughtStep(
                "生成された検索クエリ",
                query_text, 
                None
            ))
            thoughts.append(ThoughtStep(
                "検索条件",
                None,
                {
                    "チャンク取得数": top,
                    "セマンティックランカー": use_semantic_ranker,
                    "セマンティックキャプション": use_semantic_captions,
                },
            ))
            thoughts.append(ThoughtStep(
                "検索結果",
                [result.serialize_for_results() for result in results_search],
                None
            ))
                
        # 回答生成
        thoughts.append(ThoughtStep(
            "回答生成プロンプト",
            [str(message) for message in messages_for_creating_answer_display],
            {
                "GPT": overrides.get("answer_gpt_vision_input"),
                "用語集の参照": use_internal_terms,
                "フォローアップ質問": overrides.get("suggest_followup_questions"),
                "ストリーミング": should_stream,
            }
        ))
        
        # 実行時間
        thoughts.append(ThoughtStep(
            "実行時間",
            None,
            {
                "Elapsed Time": elapsed_time(start_time),
            }
        ))
        

        extra_info = {
            # Supporting content タブ
            "data_points": {"text": sources_content},
            
            # Thought Process タブ
            "thoughts": thoughts
        }
        
            
        #
        # Return
        #
        return (extra_info, chat_coroutine)
